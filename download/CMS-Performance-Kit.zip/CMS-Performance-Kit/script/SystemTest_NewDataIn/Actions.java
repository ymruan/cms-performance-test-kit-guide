/*
 * LoadRunner Java script. (Build: 3020)
 * 
 *                     
 */

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import com.hp.ucmdb.pcoe.utils.*;

import com.hp.ucmdb.api.*;
import com.hp.ucmdb.api.topology.*;
import com.hp.ucmdb.api.types.TopologyCI;
import com.hp.ucmdb.pcoe.datain.*;

import com.hp.ucmdb.pcoe.datain.*;
import lrapi.lr;


public class Actions
{
	private int m_nStartIP ;
        private int m_Add2Update;
        private int m_Update2Update;
        private int m_Update2Delete;
	private int m_Delete2Add;
        private int m_UpdateCount;
	private int m_nLoopCount;
	private DataInClient m_client ;
	private String m_sStuckOnFail = "false";
	private String m_sAbortOnFail = "true";
	private String m_sMailOnFail = "";
	private String m_sSkip = "false";
	private String m_sServerName;
	private String m_sCleanSchema = "true";
	private ArrayList<Map<String, String>> m_ListOfAttributesMap = new ArrayList<Map<String, String>>();


	public int init() throws Throwable {
	    openXML("SystemTest_NewDataIn", "CommandLine");
	    m_sSkip = getAttribute(0,"Skip", false, "false");
	    if (m_sSkip.equals("true")) {
		return 0;
	    }

	    ConnectionProperties conProp = new ConnectionProperties();

	    m_sStuckOnFail = getAttribute(0,"StuckOnFail", false, "false");//"true"\"false"
	    lr.message("StuckOnFail = " + m_sStuckOnFail);

	    m_sAbortOnFail = getAttribute(0,"AbortOnFail", false, "true");//"true"\"false"
	    lr.message("AbortOnFail = " + m_sAbortOnFail);

	    m_sMailOnFail = getAttribute(0,"MailOnFail", false, "");//"asaf@hp.com.ilevy@hp.com"
	    lr.message("MailOnFail = " + m_sMailOnFail);

	    conProp.HOST = getAttribute(0,"ServerName",true,null);//uCMDB machine
	     m_sServerName = conProp.HOST;
	    lr.message("HOST - " + conProp.HOST);


	    String sStartIP = getAttribute(0,"StartIP",true,null);
	    lr.message("StartIP - "+ sStartIP);
	    m_nStartIP = ipToInt(sStartIP);

	    String iniFile = getAttribute(0,"INI",true,null);
	    lr.message("iniFile - "+ iniFile);

	    m_nLoopCount = Integer.valueOf(getAttribute(0,"LoopCount",false,"1"));
	    lr.message("LoopCount - "+ m_nLoopCount);
            
	    conProp.CUSTOMER = getAttribute(0,"CustomerName",false,"Default Client");
	    lr.message("CUSTOMER - " + conProp.CUSTOMER);

            conProp.USER_NAME = getAttribute(0,"UserName",false,"admin");
	    lr.message("USER_NAME  - " + conProp.USER_NAME);

            conProp.PASSWORD = getAttribute(0,"Password",false,"admin");
	    lr.message("PASSWORD  - " + conProp.PASSWORD);

	    m_sCleanSchema = getAttribute(0,"CleanSchema",true, null);
	    lr.message("Clean Schema = " + m_sCleanSchema);

	    // This is a class that comes from our JAR. it handles the INI instaed of us
            // creating a specific method in vuegen.It holds all the parameters that 
            // we need for creating the topology
            
            DataInProperties DataInProperties = new DataInProperties(iniFile);

            m_UpdateCount = Integer.valueOf(getAttribute(0,"UpdateCount",false,"3"));
            lr.message("UpdateCount  - " + m_UpdateCount);

            m_Add2Update = Integer.valueOf(getAttribute(0,"Add2Update",false,"300"));
            lr.message("Add2Update  - " + m_Add2Update);

            m_Update2Update = Integer.valueOf(getAttribute(0,"Update2Update",false,"300"));
            lr.message("Update2Update  - " + m_Update2Update);

	    m_Update2Delete = Integer.valueOf(getAttribute(0,"Update2Delete",false,"300"));
            lr.message("Update2Delete  - " + m_Update2Delete);

	    m_Delete2Add = Integer.valueOf(getAttribute(0,"Delete2Add",false,"300"));
            lr.message("Delete2Add  - " + m_Delete2Add);


            m_client = new DataInClient(conProp,DataInProperties);
            m_client.init();

	    if (m_sCleanSchema.equals("true")) {

		CMDBtools cmdBtools = new CMDBtools();
		cmdBtools.cleanSchema(m_sServerName);
	    }

	    return 0;
	}//end of init


	public int action() throws Throwable {
	    if (m_sSkip.equals("true")) {
		return 0;
	    }

	   
	    for (int LoopIndex = 0 ; LoopIndex<m_nLoopCount ; LoopIndex++) {
	    m_client.generateTopology(m_nStartIP,String.valueOf(System.currentTimeMillis()));
            try{
                lr.start_transaction("DataIn_Add");
                m_client.createTopology();
                lr.end_transaction("DataIn_Add",lr.PASS);
            }catch(Exception e){
                lr.end_transaction("DataIn_Add",lr.FAIL);
		lr.error_message("DataIn script failed to create topology");
		return 0 ;
            }

            lr.think_time(m_Add2Update);

            for (int i=0;i<m_UpdateCount;i++) {
                m_client.generateTopology(m_nStartIP,String.valueOf(System.currentTimeMillis()));
                try{
                    lr.start_transaction("DataIn_Update");
                    m_client.updateTopology();
                    lr.end_transaction("DataIn_Update",lr.PASS);
                    if (i+1==m_UpdateCount)
                        break ; //Don't want it to sleep after last update, there is seperate sleep between the last update and the delete
                    lr.think_time(m_Update2Update);
                }catch(Exception e){
                    lr.end_transaction("DataIn_Update",lr.FAIL);
		    lr.error_message("DataIn script failed to update topology");
                }
            }

            lr.think_time(m_Update2Delete);

            try{
                lr.start_transaction("DataIn_Delete");
                m_client.deleteTopology();
                lr.end_transaction("DataIn_Delete",lr.PASS);
            }catch(Exception e){
                lr.end_transaction("DataIn_Delete",lr.FAIL);
		lr.error_message("DataIn script failed to delete topology");
            }
	    lr.think_time(m_Delete2Add);
	    }
	    return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end

        public String intToIp(int i) {
		return (i >> 24 & 0xFF) + "." + (i >> 16 & 0xFF) + "." + (i >> 8 & 0xFF) + "." + (i & 0xFF);
	}

        public int ipToInt(String sIP){
            String[] ipSections = sIP.split("\\.");
	    if(ipSections.length==4)
		return Integer.valueOf(ipSections[0])<<24 | Integer.valueOf(ipSections[1])<<16 | Integer.valueOf(ipSections[2])<<8 | Integer.valueOf(ipSections[3]);
	    return 0;
        }
	
	private String getAttribute(int nCommandLine,String attrName,boolean failIfNull,String defaultValue){
	if (m_ListOfAttributesMap.size()> nCommandLine)
	{
	    Map<String,String> map = m_ListOfAttributesMap.get(nCommandLine);
	    if (map.containsKey(attrName)) {
		lr.message("Attribute : " + attrName + " appears in XML");
		return map.get(attrName);
	    }else{
		if (failIfNull == true) {//in case a default value is no good
                    lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
                    sendMailOnFail("Error:SystemTest_DataIn","Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
		    stuckOnFail();
		    lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                    return "";
                } else {//in case we can use a default value
                    if (defaultValue != null) {//there IS a default value
			lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,Using default value");
                        return defaultValue;
                    } else {//no default value
                        lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
                        sendMailOnFail("Error:SystemTest_DataIn","Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
			stuckOnFail();
			lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                        return "";
                    }
                }
	    }
	}else{
	    return checkStringAttr(attrName,failIfNull,defaultValue);
	}
    }

    
    private String checkStringAttr(String attrName, boolean failIfNull, String defaultValue) {
        if (!(attrName == null)) {//we have an attribute name
            String attr = lr.get_attrib_string(attrName);
            if (attr == null) {//no param value
                if (failIfNull == true) {//in case a default value is no good
                    lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
                    sendMailOnFail("Error:SystemTest_DataIn","Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
		    stuckOnFail();
		    lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                    return "";
                } else {//in case we can use a default value
                    if (defaultValue != null) {//there IS a default value
			lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,Using default value");
                        return defaultValue;
                    } else {//no default value
                        lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
                        sendMailOnFail("Error:SystemTest_DataIn","Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
			lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                        return "";
                    }
                }
            } else {//we have param value
		lr.message("Attribute : " + attrName + " appears in command line");
                return attr;
            }
        } else {//we DONT have an attribute name at all
            lr.error_message("No attribute name supplied. Aborting VUser.");
            sendMailOnFail("Error:SystemTest_DataIn","No attribute name supplied. Aborting VUser.");
	    stuckOnFail();
	    lr.exit(lr.EXIT_VUSER, lr.FAIL); 
            return "";
        }
    }

    private void openXML(String sScriptName,String sCommandLine){
	String sSettingsXML = checkStringAttr("SettingsXML", false, "");
	lr.message("SettingsXML file : " + sSettingsXML);
	Map<String, String> attributes ;
	if (!sSettingsXML.isEmpty()) {
	    try{
	     XmlReader xmlReader = new XmlReader();
	     xmlReader.open(sSettingsXML);
	     attributes = xmlReader.getAttributes(sScriptName,sCommandLine);
	     if (attributes == null)   {
		lr.error_message("Parameter SettingsXML supplied but attributes was not found");
		sendMailOnFail("Error:SystemTest_DataIn","Parameter SettingsXML supplied but attributes was not found");
		stuckOnFail();
		lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	     }else{
		 m_ListOfAttributesMap.add(attributes);
                 while((attributes = xmlReader.getNextAttributes())!=null){
		      m_ListOfAttributesMap.add(attributes);
		 }
	     }
	    }catch(Exception e){
		lr.error_message("Exception occured during reading SettingsXML");
		lr.error_message(e.getMessage());
		sendMailOnFail("Error:SystemTest_DataIn","Exception occured during reading SettingsXML\n"+e.getMessage());
		stuckOnFail();
		lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	    }
	}else{
	    lr.message("SettingsXML file does not appear in command line, trying to get all attributes from command line");
	}
    }

    private void sendMailOnFail(String sSubject,String sMessage){
	if (m_sMailOnFail.equals(""))
	    return ;
        MailSender mailSender = new MailSender();
        mailSender.sendMail("smtp3.hp.com",m_sMailOnFail,m_sMailOnFail, sSubject, sMessage);
    }

    private void stuckOnFail(){
        if (m_sStuckOnFail.toLowerCase().equals("true")) {
	    while(true){
		lr.think_time(1);
	    }
	}
    }

    private void abortOnFail(){
        if (m_sAbortOnFail.toLowerCase().equals("true")) {
	  lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	}
    }

}
