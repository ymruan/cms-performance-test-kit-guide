// Do not change this file
/****************************************************************************************
*											*
*                                   MERCURY						*
*											*
*                       Performance Center Of Excellence				*
*											*
*		Author: Eran Brand, PCoE ET. March 2009. eran.brand@hp.com		*
*											*
*****************************************************************************************
*				Script overview						*
*****************************************************************************************
*											*
*	Product:			UCMDB                       			*
*	Product Version:	8.0.1 / 9.0						*
*											*
*	Script Author: 		Eran Brand, PCoE ET					*
*	Creation Date:		03/2009						*
*											*
*	Reviewed by	 :								*
*	Review date  : 									*
*											* 
*****************************************************************************************
*											*
*	Business Process Name: uCMDB_01_SDK_run_TQL_action  				*
*											*
*	General Business Process Description:	                                        *
*   	uCMDB 8.0.1/9.0  exposes APIs for external client application for the usage of	*
*	inner uCMDB actions								*
*	The script is written (as opposed to recorded) in Java and not in C.		*
*    	  										*
*****************************************************************************************
*											*
*											*
*											*
*	The script, runs the following TQL related actions:			 	*
*		- Create & edit TQL							*
*		- Get layout for a TQL node						*
*		- Delete TQL								*
*		- Run existing TQL							*
*											*
*	The TQL created are created while choosing source and target nodes randomally	*
*	from a set of different CITs.							*
*	The existing TQLs are ran from a list read from an INI file and executed either	*
*	randomally or sequentially.							*
*	Please take a look at the following command line parameter list for better 	*
*	understanding the script.							*
*											*
*****************************************************************************************
*											*
* Parameters:										*
* Commandline Parameters:								*
* ======================								*
* ProfilingEnabled -HIGHLY IMPORTANT- This parameter must be set to False in most cases.*<<<IMPORTANT
* 	This profiling flag determines whether or not we use the profiler. If it is set *
* 	to True a CPU snapshot will be taken for each transaction that its duration time*
* 	passes the threahold set either in TrxRunThreshold param or TrxSaveThreshold 	*
* 	param. ONLY A SINGLE VUser in each scenario (not each group) should have this 	*
* 	param set to true. otherwise, THE DISK WILL BE FLOODED WITH SNAPSHOTS eventually*
*	This Vuser also needs to run only once or twice an hour for this reason.	*
*	See also: TrxRunThreshold and TrxSaveThreshold. Default value - False.		*
* AmountOfActions - Precent of actions to be done. Values: 1=minimal, only runs 	*
* 	existing queries, 2=med additionally creates TQLs runs them and deletes them,	*
*	3=all - additionally gets a specific layout for a TQL nodes. Default value=3.	*
* ServerName - The uCMDB server to use (e.g. labm3pcoe87.devlab.ad).  No default value 	*
*	- the script fails if there's no value.			 			*
* RandFlag -  A flag that determines whether we generate TQLs randomly. If set to	*
* 	False - a hard coded TQL will be used. Default value - True.			*
* TrxRunThreshold - A time threshold for the run transactions . If breached, for 	*
*	some transactions a CPU profiling will be automatically initiate. Default val=10*
* TrxSaveThreshold - A time threshold for the save transaction . If breached, a 	*
* 	CPU profiling will be automatically initiate. Default value = 5.		*
* INI - \\\\illabstore01.devlab.ad\\users\\pcoe\\UCMDB\\ForSDK\\TQL.ini - The location 	*
*	of the INI file. No default value - the script fails if there's no value. The	*
*	format for the INI file is described below.					*
* YJPPort- 8788 - The port used to profile the relevant process by Yourkit. No default 	*
*	value - when the profiling is enabled, the script fails if there's no value.	*
* RandPredefinedTQL - True - Flag. If set to true, a random TQL will be chosen from the	*
* 	TQL list. If False - TQLs will be ran sequentially. Default value = false.	*
*											*
* LR parameters:									*
* =============										*
* RandSourceCIT - determines what CIT node will be the source node for the TQL the Vuser*
*	builds.										*
* RandTargetCIT - determines what CIT node will be the target node for the TQL the Vuser*
*	builds.										*
* Iteration - Vuser iteration number. (Used in this script for going over the TQL list)	*
* VuserID - used for unique TQL names so that TQLs with the same names will not be saved*
*	on the server.									*
*											*
*****************************************************************************************
* Classpath:										*
* =========										*
* The following enteries need to be added to the class path:				*
* 1] ucmdb-api.jar location. Currently (03/03/09) it's located at:			*
*	\\illabstore01.devlab.ad\users\pcoe\UCMDB\JARS\ucmdb-api.jar			*
* 2] yjp-controller-api-redist.jar location. Currently (03/03/09) it's located at:	*
*	\\illabstore01.devlab.ad\users\pcoe\Yourkit\Jars\yjp-controller-api-redist.jar	*
* 											*
* 											*
* 											*
*****************************************************************************************
* INI file format:									*
* ===============									*
* [TQLs]										*
* TQL3=TQL3Name										*
* TQL1=TQL1Name										*
* TQL2=TQL2Name										*
* TQL4=TQL4Name										*
* TQL6=TQL6Name										*
* TQL5=TQL5Name										*
* TQL7=TQL7Name										*
* TQL8=TQL8Name										*
* TQL9=TQL9Name										*
* 											*
* As you can see, the file consists only of the [TQLs] header and a list of TQL names 	*
* along with their numbers. The order of the lines does not effect the order of 	*
* execution. The order of execution (in case of a sequential run of course) is 		*	
* determined only acording to the TQL numbers regardless to the line order.		*
* Any other data in the INI file will cause the script to abort.			*
* 											*
* 											*
*****************************************************************************************
* Other important notes:								*
* ======================								*
* 1] Pay attention: the TQLs created by this script, are selected randomally from a set *
*	of options. If you want to be sure these TQLs meat your needs and will not 	*
*	returnempty results, run the script a few times before using it. If you see that*
*	you get many empty results, change the values assigned to the variables in the 	*
*	nested switch statement in the init method. Not sure how to do that? let me 	*
*	know:	eran.brand@hp.com 							*
* 2] In order for the TQLs to be calculated as ad hoc ones, you need to make sure they	*
*	are ALL inactive. In order to do so, go to JMX console -> 			*
*	service=CMDB Tql Services -> invoke service=CMDB Tql Services (you can leave 	*
*	customerID empty). For each TQL	name, the rightmost button is in charge of 	*
*	activating / deactivating the TQL. 						*
*****************************************************************************************/





/****************************************************************************************
*			Script history							*
*****************************************************************************************
*											*
*	Modification Date: 04/03/2009							*
*											*
*	Author: Eran Brand 	   							*
*											*
*	Description:		   							*
*****************************************************************************************
*											*
*	Modification Date:    								*
*											*
*	Author:				  						*
*											*
*	Description:									*
*											*
*											*
*											*
*****************************************************************************************
*											*
*	Modification Date:  								*
*											*
*	Author:										*
*											*
*	Description:									*
*											*
*											*
*											*
****************************************************************************************/


