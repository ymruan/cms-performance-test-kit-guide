

import java.util.ArrayList;
import java.util.Map;
import com.hp.ucmdb.pcoe.utils.*;

import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.ServiceNotFoundException;
import javax.management.openmbean.CompositeDataSupport;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import lrapi.lr;


public class Actions {
    //COMMAND LINE : -ServerName mydvm0650
   
    private JMXConnector m_JMXConnector;
    private MBeanServerConnection m_MBeanServerConnection;
    private String m_sMbeanName = "java.lang:type=Memory";
    private String m_sAttributeName =  "HeapMemoryUsage";
    private String m_sPropertyName = "used";
    private String m_sIntervalSeconds = "60" ;
    private String m_sHostName = "";
    private int m_nLoopCount = 1;
    private String m_sStuckOnFail = "false";
    private String m_sAbortOnFail = "true";
    private String m_sMailOnFail = "";
    private String m_sSkip = "false";
    private ArrayList<Map<String, String>> m_ListOfAttributesMap = new ArrayList<Map<String, String>>();

    public int init() {
	openXML("SystemTest_HeapInfo", "CommandLine");
	m_sSkip = getAttribute(0,"Skip", false, "false");
	if (m_sSkip.equals("true")) {
	    return 0;
	}

      	m_sStuckOnFail = getAttribute(0,"StuckOnFail", false, "false");//"true"\"false"
	lr.message("StuckOnFail = " + m_sStuckOnFail);

	m_sAbortOnFail = getAttribute(0,"AbortOnFail", false, "true");//"true"\"false"
	lr.message("AbortOnFail = " + m_sAbortOnFail);

	m_sMailOnFail = getAttribute(0,"MailOnFail", false, "");//"asaf@hp.com.ilevy@hp.com"
	lr.message("MailOnFail = " + m_sMailOnFail);

	m_sHostName = getAttribute(0,"ServerName", true, null);
	lr.message("Host = " + m_sHostName);

	m_sIntervalSeconds = getAttribute(0,"IntervalSeconds", true, null);
	lr.message("Interval = " + m_sIntervalSeconds);

	m_nLoopCount = Integer.valueOf(getAttribute(0,"LoopCount", false, "1"));
	lr.message("LoopCount = " + m_nLoopCount);

	initJMX(m_sHostName);
        return 0;
    }//end of init


    public int action() {
	    if (m_sSkip.equals("true")) {
		return 0;
	    }

	    int nInterval = Integer.valueOf(m_sIntervalSeconds);
	    for (int i = 0 ; i < m_nLoopCount ; i++) {
		try{
		    CompositeDataSupport sRet = (CompositeDataSupport) attributeJMX(m_sMbeanName, m_sAttributeName);
		    if (sRet != null) {
			Double used = Double.valueOf(((Long) sRet.get(m_sPropertyName))) / 1024 / 1024;
			lr.message("HeapUsage = " + used);
			lr.user_data_point("HeapUsage",used);
			lr.think_time(nInterval);
		    }
		 }catch(Exception e){
		     lr.error_message("Exception during JMX command execution");
		     lr.error_message(e.getMessage());
		     lr.think_time(5);
		 }
	    }
	    return 0;
    }//end of action


    public int end() throws Throwable {
        m_JMXConnector.close();
        return 0;
    }//end of end method


    private void initJMX(String sServer){
        try {
            JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://" + sServer + ":29601/jmxrmi");
            m_JMXConnector = JMXConnectorFactory.connect(url, null);
            m_MBeanServerConnection = m_JMXConnector.getMBeanServerConnection();
        } catch (Exception e) {
            lr.error_message("JMX Init failed : \n" + e.getMessage());
            sendMailOnFail("Error:SystemTest_HeapInfo","JMX Init failed : \n" + e.getMessage());
	    stuckOnFail();
	    abortOnFail();
        }
    }

    private Object attributeJMX(String sMbeanName, String sAttributeName) throws Exception {
	    Object ret = m_MBeanServerConnection.getAttribute(new ObjectName(sMbeanName), sAttributeName);
            return ret;       
    }


    private String getAttribute(int nCommandLine,String attrName,boolean failIfNull,String defaultValue){
	if (m_ListOfAttributesMap.size()> nCommandLine)
	{
	    Map<String,String> map = m_ListOfAttributesMap.get(nCommandLine);
	    if (map.containsKey(attrName)) {
		lr.message("Attribute : " + attrName + " appears in XML");
		return map.get(attrName);
	    }else{
		if (failIfNull == true) {//in case a default value is no good
                    lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
                    sendMailOnFail("Error:SystemTest_HeapInfo","Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
		    stuckOnFail();
		    lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                    return "";
                } else {//in case we can use a default value
                    if (defaultValue != null) {//there IS a default value
			lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,Using default value");
                        return defaultValue;
                    } else {//no default value
                        lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
                        sendMailOnFail("Error:SystemTest_HeapInfo","Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
			stuckOnFail();
			lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                        return "";
                    }
                }
	    }
	}else{
	    return checkStringAttr(attrName,failIfNull,defaultValue);
	}
    }

    
    private String checkStringAttr(String attrName, boolean failIfNull, String defaultValue) {
        if (!(attrName == null)) {//we have an attribute name
            String attr = lr.get_attrib_string(attrName);
            if (attr == null) {//no param value
                if (failIfNull == true) {//in case a default value is no good
                    lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
                    sendMailOnFail("Error:SystemTest_HeapInfo","Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
		    stuckOnFail();
		    lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                    return "";
                } else {//in case we can use a default value
                    if (defaultValue != null) {//there IS a default value
			lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,Using default value");
                        return defaultValue;
                    } else {//no default value
                        lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
                        sendMailOnFail("Error:SystemTest_HeapInfo","Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
			lr.exit(lr.EXIT_VUSER, lr.FAIL); 
                        return "";
                    }
                }
            } else {//we have param value
		lr.message("Attribute : " + attrName + " appears in command line");
                return attr;
            }
        } else {//we DONT have an attribute name at all
            lr.error_message("No attribute name supplied. Aborting VUser.");
            sendMailOnFail("Error:SystemTest_HeapInfo","No attribute name supplied. Aborting VUser.");
	    stuckOnFail();
	    lr.exit(lr.EXIT_VUSER, lr.FAIL); 
            return "";
        }
    }

    private void openXML(String sScriptName,String sCommandLine){
	String sSettingsXML = checkStringAttr("SettingsXML", false, "");
	lr.message("SettingsXML file : " + sSettingsXML);
	Map<String, String> attributes ;
	if (!sSettingsXML.isEmpty()) {
	    try{
	     XmlReader xmlReader = new XmlReader();
	     xmlReader.open(sSettingsXML);
	     attributes = xmlReader.getAttributes(sScriptName,sCommandLine);
	     if (attributes == null)   {
		lr.error_message("Parameter SettingsXML supplied but attributes was not found");
		sendMailOnFail("Error:SystemTest_HeapInfo","Parameter SettingsXML supplied but attributes was not found");
		stuckOnFail();
		lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	     }else{
		 m_ListOfAttributesMap.add(attributes);
                 while((attributes = xmlReader.getNextAttributes())!=null){
		      m_ListOfAttributesMap.add(attributes);
		 }
	     }
	    }catch(Exception e){
		lr.error_message("Exception occured during reading SettingsXML");
		lr.error_message(e.getMessage());
		sendMailOnFail("Error:SystemTest_HeapInfo","Exception occured during reading SettingsXML\n"+e.getMessage());
		stuckOnFail();
		lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	    }
	}else{
	    lr.message("SettingsXML file does not appear in command line, trying to get all attributes from command line");
	}
    }

    private void sendMailOnFail(String sSubject,String sMessage){
	if (m_sMailOnFail.equals(""))
	    return ;
        MailSender mailSender = new MailSender();
        mailSender.sendMail("smtp3.hp.com",m_sMailOnFail,m_sMailOnFail, sSubject, sMessage);
    }

    private void stuckOnFail(){
        if (m_sStuckOnFail.toLowerCase().equals("true")) {
	    while(true){
		lr.think_time(1);
	    }
	}
    }

    private void abortOnFail(){
        if (m_sAbortOnFail.toLowerCase().equals("true")) {
	  lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	}
    }

    
}


