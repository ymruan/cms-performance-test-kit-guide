import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import com.hp.ucmdb.pcoe.utils.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;

import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.ServiceNotFoundException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import com.hp.ucmdb.api.UcmdbService;
import com.hp.ucmdb.api.UcmdbServiceFactory;
import com.hp.ucmdb.api.UcmdbServiceProvider;
import com.hp.ucmdb.api.topology.TopologyQueryService;
import com.hp.ucmdb.api.topology.*;
import lrapi.lr;


public class Actions {
    //COMMAND LINE : -ServerName mydvm0650 -JMX false -Random false false -INI \\\\illabstore01.devlab.ad\\users\\pcoe\\UCMDB\\ForSDK\\AR_Core_TQLs.ini
    private boolean m_fRandom = false;
    private boolean m_fUseJmx = false;
    private Random m_rand;
    private int m_nTQLCount;
    private int m_nCurrentTQLNum = 0;
    private String m_sTQLForRunning;
    private Properties m_prop;
    private TopologyQueryService m_queryService;
    private JMXConnector m_JMXConnector;
    private MBeanServerConnection m_MBeanServerConnection;
    private String[] m_Signature = {"java.lang.Integer", "java.lang.String"};
    private String m_sMbeanName = "UCMDB:service=TQL Services";
    private String m_sFunction = "calculateTqlAdHoc";
    private String m_sStuckOnFail = "false";
    private String m_sAbortOnFail = "true";
    private String m_sMailOnFail = "";
    private String m_sSkip = "false";
    private ArrayList<Map<String, String>> m_ListOfAttributesMap = new ArrayList<Map<String, String>>();



    public int init() throws Throwable {

	openXML("SystemTest_TQLs_Execution", "CommandLine");
	m_sSkip = getAttribute(0,"Skip", false, "false");
	if (m_sSkip.equals("true")) {
	    return 0;
	}

	 m_sStuckOnFail = getAttribute(0,"StuckOnFail", false, "false");//"true"\"false"
	    lr.message("StuckOnFail = " + m_sStuckOnFail);

	    m_sAbortOnFail = getAttribute(0,"AbortOnFail", false, "true");//"true"\"false"
	    lr.message("AbortOnFail = " + m_sAbortOnFail);

	    m_sMailOnFail = getAttribute(0,"MailOnFail", false, "");//"asaf@hp.com.ilevy@hp.com"
	    lr.message("MailOnFail = " + m_sMailOnFail);

        //reading the TQLs from the INI file :
        m_prop = new Properties();//this class stores the TQLs from the INI file


        String iniFile = getAttribute(0,"INI", true, null); // (what is the parameter, do i have to supply it, default value)
        FileInputStream inStream;
        try {
            inStream = new FileInputStream(iniFile);
            m_prop.load(inStream);
            inStream.close();//closing the input stream to the INI file
        } catch (Exception e) {//file handling exception
            lr.error_message("FileInputStream problem: " + e.getMessage());
            lr.exit(lr.EXIT_VUSER, lr.FAIL);
        }
        m_nTQLCount = m_prop.size() - 1;//lines in the file minus header line since the prop doesnt know what [example] means,
	lr.message("Tql Count = " + m_nTQLCount);

        String sRandom = getAttribute(0,"Random", true, "false");//whether or not we want to execute the existing TQLs randomally
        if (sRandom.equalsIgnoreCase("true")) {
            m_fRandom = true;
	    m_rand = new Random();
	    lr.message("Random = " + sRandom);
        }


        String sHostName = getAttribute(0,"ServerName", true, null);//uCMDB machine
        // needs to add connectivity to server test
	lr.message("Host = " + sHostName);

        String sJmx = getAttribute(0,"JMX", true, "false");//whether or not we want to execute the existing TQLs randomally
        if (sJmx.equalsIgnoreCase("true")) {
            m_fUseJmx = true;
            initJMX(sHostName);
	    lr.message("JMX = " + sJmx);
        } else {
            try {
                UcmdbServiceProvider provider = UcmdbServiceFactory.getServiceProvider(sHostName, 8080);//getting a uCMDB service provider
                UcmdbService ucmdbService = provider.connect(provider.createCredentials("admin", "admin"), provider.createClientContext("admin"));//getting a uCMDB service from the provider
                m_queryService = ucmdbService.getTopologyQueryService();
            } catch (Exception e) {
                lr.error_message("Exception at getting connection/provider from ucmdb" + e.getMessage());
                throw new RuntimeException(e);
            }
        }

        return 0;
    }//end of init


    public int action() throws Throwable {
	m_sSkip = getAttribute(0,"Skip", false, "false");
	if (m_sSkip.equals("true")) {
	    return 0;
	}

        try {
	    //  This section sets the TQL execution randomly,
            if (m_fRandom == true) {//excuting existing TQLs randomally
                m_nCurrentTQLNum = m_rand.nextInt(m_nTQLCount) + 1;//select a random number

            } else {//if we want to run sequentially
                m_nCurrentTQLNum++;
                if (m_nCurrentTQLNum > m_nTQLCount)
                    m_nCurrentTQLNum = 1;
            }
            //the following code builds the TQL key value from the INI file according the correct order by
            // adding the correct number to the string "TQL".
            m_sTQLForRunning = m_prop.getProperty("TQL" + m_nCurrentTQLNum);//get the matching TQL
	    lr.message("Current TQL = " + m_sTQLForRunning);

            if (m_fUseJmx == true) {
                runExistingQueryByJMX(m_sTQLForRunning);
            } else {
                runExistingQueryBySDK(m_sTQLForRunning);
            }
        } catch (Exception e) {
            lr.error_message(e.getMessage());
            lr.exit(lr.EXIT_VUSER, lr.FAIL);
        }
        return 0;
    }//end of action


    public int end() throws Throwable {
        return 0;
    }//end of end method


    public void runExistingQueryBySDK(String queryName) {

        try {
	    double duration;
            lr.start_transaction("SDK_calculateAdHocTQL_" + queryName);
            m_queryService.executeNamedQuery(queryName);//running the query
	    //Topology topology = m_queryService.executeNamedQuery(queryName);//running the query , No Need to keep results to var , here to test compatibility with old script
	    //duration = lr.get_transaction_duration("SDK_calculateAdHocTQL_" + queryName);//NO Need , Only here to test compatibility with old script
            lr.end_transaction("SDK_calculateAdHocTQL_" + queryName, lr.PASS);
        } catch (Exception e) {
            lr.end_transaction("SDK_calculateAdHocTQL_" + queryName, lr.FAIL);
            lr.error_message("TQL " + queryName + " Execution exception : " + e.getMessage());
        }
    }

    public void runExistingQueryByJMX(String queryName) {
        Object[] params = {1, queryName};
        try {
            lr.start_transaction("JMX_calculateAdHocTQL_" + queryName);
            // the signature contains an array of Strings that represents the java type. For examaple: "java.lang.Integer, java.lang.String" 
            executeJMX(m_sMbeanName, m_sFunction, params, m_Signature);
            lr.end_transaction("JMX_calculateAdHocTQL_" + queryName, lr.PASS);
        } catch (Exception e) {
            lr.end_transaction("JMX_calculateAdHocTQL_" + queryName, lr.FAIL);
            lr.error_message("TQL " + queryName + " Execution exception : " + e.getMessage());
        }
    }

    private void initJMX(String sServer) throws IOException {
        try {
            JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://" + sServer + ":29601/jmxrmi");
            m_JMXConnector = JMXConnectorFactory.connect(url, null);
            m_MBeanServerConnection = m_JMXConnector.getMBeanServerConnection();
        } catch (Exception e) {//file handling exception
            lr.error_message("JMX Init failed : " + e.getMessage());
            lr.exit(lr.EXIT_VUSER, lr.FAIL);
        }
    }

    private Object executeJMX(String sMbeanName, String sFunctionName, Object[] params, String[] signature) throws Exception {
        try {
/*          MBeanInfo ret = m_MBeanServerConnection.getMBeanInfo(new ObjectName(m_sMbeanName));
            MBeanOperationInfo[] ops = ret.getOperations();
            MBeanParameterInfo[] sig = ops[0].getSignature()*/
            if (m_MBeanServerConnection == null)
                throw new NullPointerException("JMX was not initialized");

            //String key = sMbeanName + " - " + sFunctionName;
            Object obj = m_MBeanServerConnection.invoke(new ObjectName(sMbeanName), sFunctionName, params, signature);
            return obj;
        } catch (MBeanException e) {
            if (e.getCause() instanceof ServiceNotFoundException)
                throw (ServiceNotFoundException) e.getCause();
            throw e;
        } catch (Exception e) {
            throw new Exception("JMX Internal error - " + e.getMessage());
        }
    }



    private String getAttribute(int nCommandLine,String attrName,boolean failIfNull,String defaultValue){
 if (m_ListOfAttributesMap.size()> nCommandLine)
 {
     Map<String,String> map = m_ListOfAttributesMap.get(nCommandLine);
     if (map.containsKey(attrName)) {
	 lr.message("Attribute : " + attrName + " appears in XML");
	 return map.get(attrName);
     }else{
	 if (failIfNull == true) {//in case a default value is no good
	     lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
	     sendMailOnFail("Error:SystemTest_TQLs_Execution","Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
	     stuckOnFail();
	     lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	     return "";
	 } else {//in case we can use a default value
	     if (defaultValue != null) {//there IS a default value
		 lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,Using default value");
		 return defaultValue;
	     } else {//no default value
		 lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
		 sendMailOnFail("Error:SystemTest_TQLs_Execution","Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
		 stuckOnFail();
		 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
		 return "";
	     }
	 }
     }
 }else{
     return checkStringAttr(attrName,failIfNull,defaultValue);
 }
}


private String checkStringAttr(String attrName, boolean failIfNull, String defaultValue) {
 if (!(attrName == null)) {//we have an attribute name
     String attr = lr.get_attrib_string(attrName);
     if (attr == null) {//no param value
	 if (failIfNull == true) {//in case a default value is no good
	     lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
	     sendMailOnFail("Error:SystemTest_TQLs_Execution","Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
	     stuckOnFail();
	     lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	     return "";
	 } else {//in case we can use a default value
	     if (defaultValue != null) {//there IS a default value
		 lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,Using default value");
		 return defaultValue;
	     } else {//no default value
		 lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
		 sendMailOnFail("Error:SystemTest_TQLs_Execution","Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
		 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
		 return "";
	     }
	 }
     } else {//we have param value
	 lr.message("Attribute : " + attrName + " appears in command line");
	 return attr;
     }
 } else {//we DONT have an attribute name at all
     lr.error_message("No attribute name supplied. Aborting VUser.");
     sendMailOnFail("Error:SystemTest_TQLs_Execution","No attribute name supplied. Aborting VUser.");
     stuckOnFail();
     lr.exit(lr.EXIT_VUSER, lr.FAIL); 
     return "";
 }
}

private void openXML(String sScriptName,String sCommandLine){
 String sSettingsXML = checkStringAttr("SettingsXML", false, "");
 lr.message("SettingsXML file : " + sSettingsXML);
 Map<String, String> attributes ;
 if (!sSettingsXML.isEmpty()) {
     try{
      XmlReader xmlReader = new XmlReader();
      xmlReader.open(sSettingsXML);
      attributes = xmlReader.getAttributes(sScriptName,sCommandLine);
      if (attributes == null)   {
	 lr.error_message("Parameter SettingsXML supplied but attributes was not found");
	 sendMailOnFail("Error:SystemTest_TQLs_Execution","Parameter SettingsXML supplied but attributes was not found");
	 stuckOnFail();
	 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
      }else{
	  m_ListOfAttributesMap.add(attributes);
	  while((attributes = xmlReader.getNextAttributes())!=null){
	       m_ListOfAttributesMap.add(attributes);
	  }
      }
     }catch(Exception e){
	 lr.error_message("Exception occured during reading SettingsXML");
	 lr.error_message(e.getMessage());
	 sendMailOnFail("Error:SystemTest_TQLs_Execution","Exception occured during reading SettingsXML\n"+e.getMessage());
	 stuckOnFail();
	 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
     }
 }else{
     lr.message("SettingsXML file does not appear in command line, trying to get all attributes from command line");
 }
}

private void sendMailOnFail(String sSubject,String sMessage){
 if (m_sMailOnFail.equals(""))
     return ;
 MailSender mailSender = new MailSender();
 mailSender.sendMail("smtp3.hp.com",m_sMailOnFail,m_sMailOnFail, sSubject, sMessage);
}

private void stuckOnFail(){
 if (m_sStuckOnFail.toLowerCase().equals("true")) {
     while(true){
	 lr.think_time(1);
     }
 }
}

private void abortOnFail(){
 if (m_sAbortOnFail.toLowerCase().equals("true")) {
   lr.exit(lr.EXIT_VUSER, lr.FAIL); 
 }
}

}


