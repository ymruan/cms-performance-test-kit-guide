Sleep1()
{
	lr_think_time(dbSleep1);
	return 0;
}
