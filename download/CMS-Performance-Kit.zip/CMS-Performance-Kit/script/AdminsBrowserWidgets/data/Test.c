Test()
{

	lr_think_time(7);

	web_custom_request("ucmdb_browser.rpc_62", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t1078.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|editingAllowed|java.lang.String/2004016611|564ce93708c7fdcd1df8ab8351fea93a|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_63", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t1079.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getExpandedCIProperties|java.lang.String/2004016611|564ce93708c7fdcd1df8ab8351fea93a|1|2|3|4|1|5|6|", 
		LAST);

	return 0;
}