Browser2_PropertyWidgetWin()
{

	lr_think_time(96);

	web_custom_request("ucmdb_browser.rpc_60", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%202011;search-selection=4243a973a7498337d243a06963fb6e9f", 
		"Snapshot=t708.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|editingAllowed|java.lang.String/2004016611|4243a973a7498337d243a06963fb6e9f|1|2|3|4|1|5|6|", 
		LAST);

	web_add_cookie("LWSSO_COOKIE_KEY=Uz4v72uK-iqyp-Y6NhGnSAPq7NPagvdAIrGpCbA6Zigaxo43axp5PK4-z0vKd6zr9l_IK3fAlGFobgQWLrGRXKRLdJdwepxrWpaPehz2PnCjv7pfiigjcFMS0igkbWhbNC6kWD7Y7cdgWusBQSuAxhu80fjIsW-Pqmcw7YAZ0HEyhYBkfiO08X0Tj9NOCN_q8h-5pn1YbInVQX4YndrwpqprlypNR74Ds2-lHs3ub_I.; DOMAIN=labm3pcoe103");

	web_custom_request("ucmdb_browser.rpc_61", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%202011;search-selection=4243a973a7498337d243a06963fb6e9f", 
		"Snapshot=t709.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getExpandedCIProperties|java.lang.String/2004016611|4243a973a7498337d243a06963fb6e9f|1|2|3|4|1|5|6|", 
		LAST);

	return 0;
}
