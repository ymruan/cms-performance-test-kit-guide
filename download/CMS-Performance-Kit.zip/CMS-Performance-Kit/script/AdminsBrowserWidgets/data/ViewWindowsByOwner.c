ViewWindowsByOwner()
{

	lr_start_transaction("Browser_ViewWindowsByOwner");

	web_custom_request("ucmdb_browser.rpc_158", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t182.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|27|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1250|, height: |662|offset width: |1236|, offset height:|547|computed width: |, computed height:|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|groups|[(Location ,1),(JEE,1),(Database ,1),(Web Server ,1),(Infrastructure ,127),(Network ,3),(Other ,1)]|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|number_of_direct_stakeholders|1|number_of_indirect_stakeholders|0|1|2|3|4|2|5|6|TuExY7n|6|7|5|8|0|7|6|9|10|9|11|9|12|9|13|9|14|9|15|9|16|9|17|9|18|-10|9|19|-12|20|1|7|0|20|3|7|1|9|21|9|22|23|1|7|0|23|3|7|2|9|24|9|25|9|26|9|27|21|", 
		LAST);

	web_add_cookie("LWSSO_COOKIE_KEY=juG-m6CTtv-o0_mSlM-ntURYhTEtzb7ekvxbo0P6m7RQ4hQqz5ZFeSIYrp0JxW5ySyxOfD8rKFj_0LHz6LU-snFQcJRFNjNGzcKFu9NBLVLY33Z3CySEBrQqpn65W_JVcbNyhoU8q9-BG1ak0swVZJw6giYYCQ_-1Y0IAYS1WrJ3uLhLTuwioImSquTxLdb7HynUY7Zz7bJ2CnYvjO8pKy31uyf9qnywDMwAd9B3rk0.; DOMAIN=labm3pcoe123");

	web_custom_request("ucmdb_browser.rpc_159", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t183.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|17|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1250|, height: |662|offset width: |, offset height:|computed width: |, computed height:|1|2|3|4|2|5|6|TuExY76|6|7|1|8|0|7|6|9"
		"|10|9|11|9|12|9|13|9|14|-6|9|15|-8|9|16|-6|9|17|-8|22|", 
		LAST);

	web_add_cookie("LWSSO_COOKIE_KEY=U703CbLPOudlaBIsUf1fteAOsgvND3moakh7HGLS-EVWseqOnF5IZd_DNyqCy7RbaQFpAO7nZ09-8Pl-r3vqnpe19BgzWSmAQXBq2oql5JMVN8tQhM8FPfg8d0goxWjNHEzyvYZAh-hW-QTgAdun5aGWtTBYWu5sgQSmxSA8O86QJd3bTH9tUFBjlneEQO5WYW1OwcMDuZGcrQ3tJamUg9gkk151RPHZ5_fI84mZIVY.; DOMAIN=labm3pcoe123");

	web_custom_request("ucmdb_browser.rpc_160", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t184.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreviewCIProperties|java.lang.String/2004016611|b894cd95f2a5924cfd7ec47e86b42305|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_161", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t185.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|b894cd95f2a5924cfd7ec47e86b42305|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_162", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t186.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|b894cd95f2a5924cfd7ec47e86b42305|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_163", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t187.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ciWasVisited|java.lang.String/2004016611|b894cd95f2a5924cfd7ec47e86b42305|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_164", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t188.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getImpactCIsPreview|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.impact.ImpactSeverity/3147780506|b894cd95f2a5924cfd7ec47e86b42305|1|2|3|4|2|5|6|7|6|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_165", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t189.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|9|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getHistoryChangesCount|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.history.HistoryChangesFilter/622495879|Z|b894cd95f2a5924cfd7ec47e86b42305|java.util.Date/3385151746|1|2|3|4|3|5|6|7|8|6|9|Tr0k4BA|9|TuExZBA|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_166", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t190.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|23|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1250|, height: |525|offset width: |, offset height:|660|computed width: |, computed height:|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|1|2|3|4|2|5|6|TuExZCx|6|7|6|8|0|7|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-11|19|0|7|0|20|0|7|0|21|0|7|"
		"0|22|0|7|0|23|0|7|0|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_167", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t191.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsPreview|java.lang.String/2004016611|b894cd95f2a5924cfd7ec47e86b42305|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_168", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t192.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|computed width: |1250|, computed height:|658|width: |, height: |523|offset width: |, offset height:|1|2|3|4|2|5|6|TuExZFF|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_169", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t193.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getStakeholderDataModel|java.lang.String/2004016611|b894cd95f2a5924cfd7ec47e86b42305|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_170", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20windows%20owned%20by%20PCoE_Ida_PCoE;tab=search;search-selection=b894cd95f2a5924cfd7ec47e86b42305", 
		"Snapshot=t194.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostVisitedCIs|1|2|3|4|0|", 
		LAST);

	lr_end_transaction("Browser_ViewWindowsByOwner",LR_AUTO);

	return 0;
}