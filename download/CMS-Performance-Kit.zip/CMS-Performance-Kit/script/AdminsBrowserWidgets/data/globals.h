#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "web_api.h"
#include "lrw_custom_body.h"







//--------------------------------------------------------------------
// Global Variables
// char* pLoginOnce;
char* pLoginOnce;
int   fLoginDone = 0;
double dbSleep1;
double dbSleep2;
double dbSleep3;
double dbSleep4;
double dbSleep5;
double dbSleep6;
double dbSleep7;
double dbSleep8;








#endif // _GLOBALS_H
