ViewSqlServerByLocation()
{

	lr_start_transaction("Browser_ViewSqlServerByLocation");

	web_custom_request("ucmdb_browser.rpc_79", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t103.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|offset width: |1250|, offset height:|662|computed width: |, computed height:|527|width: |, height: |1|2|3|4|2|5|6|TuEwQ_G|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_80", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t104.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsPreview|java.lang.String/2004016611|36440624801a8bc23a5b23321605fb48|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_81", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t105.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getImpactCIsPreview|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.impact.ImpactSeverity/3147780506|36440624801a8bc23a5b23321605fb48|1|2|3|4|2|5|6|7|6|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_82", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t106.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreviewCIProperties|java.lang.String/2004016611|36440624801a8bc23a5b23321605fb48|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_83", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t107.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|36440624801a8bc23a5b23321605fb48|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_84", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t108.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|36440624801a8bc23a5b23321605fb48|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_85", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t109.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|9|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getHistoryChangesCount|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.history.HistoryChangesFilter/622495879|Z|36440624801a8bc23a5b23321605fb48|java.util.Date/3385151746|1|2|3|4|3|5|6|7|8|6|9|Tr0jwEN|9|TuEwREN|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_86", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t110.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ciWasVisited|java.lang.String/2004016611|36440624801a8bc23a5b23321605fb48|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_87", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t111.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|22|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1250|, height: |660|offset width: |, offset height:|computed width: |, computed height:|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|1|2|3|4|2|5|6|TuEwREp|6|7|6|8|0|7|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|-8|9|16|-6|9|17|-8|18|0|7|0|19|0|7|0|20|0|7|0|"
		"21|0|7|0|22|0|7|0|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_88", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1250|, height: |658|offset width: |, offset height:|computed width: |, computed height:|523|1|2|3|4|2|5|6|TuEwRHM|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|-8|9|16|-6|9|17|9|18|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_89", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getStakeholderDataModel|java.lang.String/2004016611|36440624801a8bc23a5b23321605fb48|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_90", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search;search-selection=36440624801a8bc23a5b23321605fb48", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostVisitedCIs|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_91", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=All%20sql%20servers%20located%20in%20holon;tab=search", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|38|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|computed width: |1250|, computed height:|523|width: |1237|, height: |547|offset width: |, offset height:|658|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|number_of_properties|3|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|severity_count|[(Critical,0),(Low,0),(High,0),(Medium,0)]|com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|groups|[(Infrastructure ,1),(Other ,1)]|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/"
		"3845702|number_of_direct_stakeholders|0|number_of_indirect_stakeholders|1|maximum_daily_changes|minimum_daily_changes|number_of_days_with_changes|1|2|3|4|2|5|6|TuEwUSq|6|7|11|8|0|7|6|9|10|9|11|9|12|9|13|9|14|9|15|9|16|9|17|9|18|-6|9|19|9|20|21|1|7|0|21|3|7|1|9|22|9|23|24|1|7|0|24|3|7|1|9|25|9|26|27|1|7|0|28|1|7|0|28|3|7|1|9|29|9|30|31|1|7|0|31|3|7|2|9|32|9|33|9|34|9|35|27|3|7|3|9|36|-41|9|37|-41|9|38|-41|22|", 
		LAST);

	lr_end_transaction("Browser_ViewSqlServerByLocation",LR_AUTO);

	return 0;
}
