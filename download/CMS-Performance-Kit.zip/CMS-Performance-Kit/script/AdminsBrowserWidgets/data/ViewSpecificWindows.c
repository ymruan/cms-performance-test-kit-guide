ViewSpecificWindows()
{

	lr_start_transaction("Browser_ViewSpecificWindows");

	web_custom_request("ucmdb_browser.rpc_254", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t535.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|computed width: |1326|, computed height:|662|width: |, height: |565|offset width: |, offset height:|1|2|3|4|2|5|6|Tu3vS8N|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_255", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t536.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ciWasVisited|java.lang.String/2004016611|313b9b73baa81d0763f9ca1587f63941|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_256", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t537.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForKey|java.lang.String/2004016611|history_ui_mode|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_257", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t538.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|313b9b73baa81d0763f9ca1587f63941|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_258", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t539.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|313b9b73baa81d0763f9ca1587f63941|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_259", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t540.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|23|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|offset width: |1326|, offset height:|660|computed width: |, computed height:|565|width: |, height: |"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|1|2|3|4|2|5|6|Tu3vTDI|6|7|6|8|0|7|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|19|0|7|0|20|0|7|0|21|0|7|0"
		"|22|0|7|0|23|0|7|0|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_260", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t541.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1326|, height: |563|offset width: |, offset height:|658|computed width: |, computed height:|1|2|3|4|2|5|6|Tu3vTEj|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_261", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t542.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getImpactCIsPreview|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.impact.ImpactSeverity/3147780506|313b9b73baa81d0763f9ca1587f63941|1|2|3|4|2|5|6|7|6|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_262", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t543.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|9|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getHistoryChangesCount|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.history.HistoryChangesFilter/622495879|Z|313b9b73baa81d0763f9ca1587f63941|java.util.Date/3385151746|1|2|3|4|3|5|6|7|8|6|9|TsniyS9|9|Tu3vTS9|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_263", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t544.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostVisitedCIs|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_264", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t545.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getStakeholderDataModel|java.lang.String/2004016611|313b9b73baa81d0763f9ca1587f63941|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_265", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t546.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsPreview|java.lang.String/2004016611|313b9b73baa81d0763f9ca1587f63941|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_266", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t547.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|30|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1326|, height: |563|offset width: |, offset height:|658|computed width: |, computed height:|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|severity_count|[(Critical,2),(High,0),(Low,0),(Medium,4)]|maximum_daily_changes|0|minimum_daily_changes|number_of_days_with_changes|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|number_of_direct_stakeholders|1|number_of_indirect_stakeholders|1|2|3|4|2|5|6|Tu3vT0Z|6|7|7|8|0|7|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17"
		"|-6|9|18|-8|19|1|7|0|20|1|7|0|20|3|7|1|9|21|9|22|19|3|7|3|9|23|9|24|9|25|-25|9|26|-25|27|1|7|0|27|3|7|2|9|28|9|29|9|30|-25|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_267", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=nt_0.0.0.1_10;tab=search;search-selection=313b9b73baa81d0763f9ca1587f63941", 
		"Snapshot=t548.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreviewCIProperties|java.lang.String/2004016611|313b9b73baa81d0763f9ca1587f63941|1|2|3|4|1|5|6|", 
		LAST);

	lr_end_transaction("Browser_ViewSpecificWindows",LR_AUTO);

	return 0;
}
