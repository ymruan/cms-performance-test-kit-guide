Logout()
{

	lr_start_transaction("Browser_Logout");

	web_url("logout.jsp", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/public/logout.jsp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/FADCF55F029ECD552E0C2F9897D0CB5B.cache.html", 
		"Snapshot=t245.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_url("ucmdb_browser.jsp", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/public/logout.jsp", 
		"Snapshot=t246.inf", 
		"Mode=HTML", 
		LAST);

	web_url("FADCF55F029ECD552E0C2F9897D0CB5B.cache.html_3", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/FADCF55F029ECD552E0C2F9897D0CB5B.cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t247.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_18", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t248.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreLoginData|1|2|3|4|0|", 
		LAST);

	lr_end_transaction("Browser_Logout",LR_AUTO);

	return 0;
}