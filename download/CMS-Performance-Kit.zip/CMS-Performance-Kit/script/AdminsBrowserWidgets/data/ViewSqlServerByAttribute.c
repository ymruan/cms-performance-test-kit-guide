ViewSqlServerByAttribute()
{

	lr_start_transaction("Browser_ViewSqlServerByAttribute");

	web_custom_request("ucmdb_browser.rpc_307", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t596.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|computed width: |1326|, computed height:|662|width: |, height: |565|offset width: |, offset height:|1|2|3|4|2|5|6|Tu3wEHb|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_308", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t597.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ciWasVisited|java.lang.String/2004016611|840be7c2c0842a09ef677b0ab0be4a1d|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_309", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t598.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForKey|java.lang.String/2004016611|history_ui_mode|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_310", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t599.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getImpactCIsPreview|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.impact.ImpactSeverity/3147780506|840be7c2c0842a09ef677b0ab0be4a1d|1|2|3|4|2|5|6|7|6|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_311", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t600.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsPreview|java.lang.String/2004016611|840be7c2c0842a09ef677b0ab0be4a1d|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_312", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t601.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreviewCIProperties|java.lang.String/2004016611|840be7c2c0842a09ef677b0ab0be4a1d|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_313", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t602.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|840be7c2c0842a09ef677b0ab0be4a1d|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_314", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t603.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|840be7c2c0842a09ef677b0ab0be4a1d|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_315", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t604.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getStakeholderDataModel|java.lang.String/2004016611|840be7c2c0842a09ef677b0ab0be4a1d|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_316", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t605.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1326|, height: |563|offset width: |, offset height:|658|computed width: |, computed height:|1|2|3|4|2|5|6|Tu3wEQ8|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_317", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t606.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|23|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|offset width: |1326|, offset height:|660|computed width: |, computed height:|565|width: |, height: |"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|1|2|3|4|2|5|6|Tu3wEPW|6|7|6|8|0|7|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|19|0|7|0|20|0|7|0|21|0|7|0"
		"|22|0|7|0|23|0|7|0|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_318", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t607.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|33|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1326|, height: |563|offset width: |, offset height:|658|computed width: |, computed height:|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|severity_count|[(Critical,0),(High,0),(Low,0),(Medium,0)]|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|groups|[(Infrastructure ,1),(Other ,1)]|com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|number_of_properties|3|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/"
		"3845702|number_of_direct_stakeholders|0|number_of_indirect_stakeholders|1|1|2|3|4|2|5|6|Tu3wErO|6|7|10|8|0|7|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|19|1|7|0|20|1|7|0|20|3|7|1|9|21|9|22|23|1|7|0|23|3|7|1|9|24|9|25|26|1|7|0|26|3|7|1|9|27|9|28|29|1|7|0|29|3|7|2|9|30|9|31|9|32|9|33|21|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_319", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t608.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|9|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getHistoryChangesCount|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.history.HistoryChangesFilter/622495879|Z|840be7c2c0842a09ef677b0ab0be4a1d|java.util.Date/3385151746|1|2|3|4|3|5|6|7|8|6|9|TsnjjiA|9|Tu3wEiA|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_320", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=0.0.0.1%20with%20version%202010;tab=search;search-selection=840be7c2c0842a09ef677b0ab0be4a1d", 
		"Snapshot=t609.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostVisitedCIs|1|2|3|4|0|", 
		LAST);

	lr_end_transaction("Browser_ViewSqlServerByAttribute",LR_AUTO);

	return 0;
}