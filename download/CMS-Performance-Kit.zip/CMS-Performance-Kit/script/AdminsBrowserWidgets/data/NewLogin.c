NewLogin()
{

	lr_start_transaction("Browser_Login");

	web_custom_request("ucmdb_browser.rpc_2", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|login|java.lang.String/2004016611|Z|admin|Server-1|1|2|3|4|4|5|5|5|6|7|7|8|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_3", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUCMDBUserLocale|1|2|3|4|0|", 
		LAST);

	web_url("ucmdb-browser_2", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/FADCF55F029ECD552E0C2F9897D0CB5B.cache.html", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("FADCF55F029ECD552E0C2F9897D0CB5B.cache.html_2", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/FADCF55F029ECD552E0C2F9897D0CB5B.cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_4", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreLoginData|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_5", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUCMDBUserLocale|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_6", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForEnvironmentWidgetForKey|java.lang.String/2004016611|SEARCH_MODE|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=deferredjs/FADCF55F029ECD552E0C2F9897D0CB5B/18.cache.js", "Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_7", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getIntegerConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_8", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getIntegerConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_9", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getIntegerConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|2|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_10", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getCategories|1|2|3|4|0|", 
		EXTRARES, 
		"Url=../gxt/themes/slate/images/slate/button/btn.gif", "Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", ENDITEM, 
		"Url=../gxt/themes/slate/images/slate/button/arrow.gif", "Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", ENDITEM, 
		"Url=base/images/grid/grid3-hd-btn.gif", "Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_11", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|triggerEmptyQueryForInitialization|1|2|3|4|0|", 
		EXTRARES, 
		"Url=deferredjs/FADCF55F029ECD552E0C2F9897D0CB5B/17.cache.js", "Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_12", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |872|, height: |503|offset width: |0|, offset height:|computed width: |, computed height:|1|2|3|4|2|5|6|TuEvADz|6|7|1|8|0|7|6|"
		"9|10|9|11|9|12|9|13|9|14|9|15|9|16|-10|9|17|-6|9|18|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_13", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_14", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getStringConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_15", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getBooleanConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_16", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getBooleanConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_17", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostVisitedCIs|1|2|3|4|0|", 
		EXTRARES, 
		"Url=../icons/nt/nt_32.gif", "Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", ENDITEM, 
		LAST);

	lr_end_transaction("Browser_Login",LR_AUTO);

	return 0;
}
