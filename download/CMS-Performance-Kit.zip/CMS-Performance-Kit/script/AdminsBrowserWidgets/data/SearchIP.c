SearchIP()
{

	web_custom_request("ucmdb_browser.rpc_18", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_19", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_20", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.0|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_21", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.0.|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_22", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.0.0|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_23", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.0.0.|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_24", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.0.0.1|1|2|3|4|1|5|6|", 
		LAST);

	lr_start_transaction("Browser_SearchIP");

	web_custom_request("ucmdb_browser.rpc_25", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#tab=search", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ucmdbBrowserUserSearch|I|java.lang.String/2004016611|0.0.0.110|com.hp.ucmdb_browser.client.search.NewSearchController@827|1|2|3|4|3|5|6|6|8|7|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_26", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|8|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_27", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_28", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsWithPaging|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|I|All results|1|2|3|4|2|5|6|5|7|16|0|8|8|", 
		EXTRARES, 
		"Url=../icons/router/router_32.gif", "Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_29", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsUpdate|I|1|2|3|4|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_30", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t54.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_31", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|8|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_32", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t56.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|13|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|searchWithResults|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.SearchResultsInitialData/788401547|0.0.0.110|java.util.HashMap/1797211028|nt|java.lang.Integer/3438268394|router|Windows|Router|1|2|3|4|2|5|6|7|6|8|2|5|9|10|1|5|11|-4|1|1|8|2|5|12|-4|5|13|-4|8|0|0|2|", 
		LAST);

	lr_end_transaction("Browser_SearchIP",LR_AUTO);

	return 0;
}
