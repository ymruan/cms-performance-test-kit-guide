Browser2_HistWidgetWin()
{

	lr_think_time(9);

	web_url("19.cache.js", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/deferredjs/424385F2CC8703D06F18B9F5E3882982/19.cache.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t885.inf", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_58", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t886.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForKey|java.lang.String/2004016611|history_ui_mode|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=../gxt/themes/slate/images/slate/grid/grid3-hd-btn.gif", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../gxt/themes/slate/images/slate/grid/grid3-hrow.gif", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_59", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t887.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|setUserPreferenceForKey|java.lang.String/2004016611|java.util.ArrayList/4159755760|history_date_from|1381788000754|1|2|3|4|2|5|6|7|6|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_60", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t888.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|setUserPreferenceForKey|java.lang.String/2004016611|java.util.ArrayList/4159755760|history_date_to|1382430626754|1|2|3|4|2|5|6|7|6|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_61", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t889.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|9|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getHistoryChanges|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.history.HistoryChangesFilter/622495879|Z|564ce93708c7fdcd1df8ab8351fea93a|java.util.Date/3385151746|1|2|3|4|4|5|6|7|7|8|6|9|UG4$6Hy|9|UHfSVPC|0|1|", 
		LAST);

	return 0;
}