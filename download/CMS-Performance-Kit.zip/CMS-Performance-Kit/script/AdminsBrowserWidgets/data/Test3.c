Test3()
{

	lr_think_time(13);

	web_custom_request("ucmdb_browser.rpc_78", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t1254.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsExpanded|java.lang.String/2004016611|564ce93708c7fdcd1df8ab8351fea93a|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_79", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t1255.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getEnvironmentWidgetDeployedQueryName|java.lang.String/2004016611|564ce93708c7fdcd1df8ab8351fea93a|1|2|3|4|1|5|6|", 
		LAST);

	web_submit_data("loadCmdbQuery_3", 
		"Action=http://labm3pcoe103:8088/ucmdb-browser/TopologyVisualization/actions/loadCmdbQuery", 
		"Method=POST", 
		"RecContentType=text/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t1256.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=queryName", "Value=MIZI_ENVIRONMENT_FOR_MAP_WITH_LOCAL_DATA_STORE", ENDITEM, 
		"Name=layout", "Value=classification", ENDITEM, 
		"Name=selectedCi", "Value=564ce93708c7fdcd1df8ab8351fea93a", ENDITEM, 
		"Name=idsRestrictions", "Value=[\"564ce93708c7fdcd1df8ab8351fea93a\"]", ENDITEM, 
		LAST);

	web_submit_data("loadGraph_3", 
		"Action=http://labm3pcoe103:8088/ucmdb-browser/TopologyVisualization/loadGraph", 
		"Method=POST", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=path", "Value=TopologyGraph", ENDITEM, 
		EXTRARES, 
		"Url=getWorldBounds?path=TopologyGraph&seq=bab242c0-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", ENDITEM, 
		"Url=getHierarchyInfo?path=TopologyGraph&dojo.preventCache=1382447174118", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", ENDITEM, 
		LAST);

	web_submit_data("getElementBounds_3", 
		"Action=http://labm3pcoe103:8088/ucmdb-browser/TopologyVisualization/getElementBounds?path=TopologyGraph&x=0&y=-38&width=1391&height=323&types=5", 
		"Method=POST", 
		"RecContentType=text/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t1257.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		EXTRARES, 
		"Url=getImage?zoom=1&col=0&row=-1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=0&row=-2&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=0&row=1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=1&row=-2&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=1&row=-1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=1&row=1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=0&row=0&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=2&row=-2&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_80", 
		"URL=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search=nt_0.0.0.141_11;tab=search;search-selection=564ce93708c7fdcd1df8ab8351fea93a", 
		"Snapshot=t1258.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser/|DA65523005832CD644525E93C2B9A663|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSelectedContextNodeId|java.lang.String/2004016611|TopologyGraph|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=1&row=0&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=2&row=-1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=2&row=0&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=2&row=1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://labm3pcoe103:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	return 0;
}