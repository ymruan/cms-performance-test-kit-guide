PropertiesWidgetWin()
{

	return 0;
}
