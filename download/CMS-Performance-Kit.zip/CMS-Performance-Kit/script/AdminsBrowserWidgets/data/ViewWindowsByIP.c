ViewWindowsByIP()
{

	lr_start_transaction("Browser_ViewWindowsByIP");

	web_custom_request("ucmdb_browser.rpc_33", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|offset width: |1250|, offset height:|660|computed width: |, computed height:|width: |, height: |565|1|2|3|4|2|5|6|TuEvv6q|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|-8|9|16|-6|9|17|9|18|22|", 
		LAST);

	web_add_cookie("LWSSO_COOKIE_KEY=cSzXZA06xZWmf9ZT8b94oDsDb6PYS0h2GZiF7C-k2qfBGlyXfiWQ16ouDZdle1CW-W26bILFeU0kpNqhSrJ421UGtim94CHOU5cgsGQgIhjfUWH6I_5EIS9vzwOLPrFZs2gS1JA5elzZkXcVA1k1rICnKzyCQiN4kaEwjUQuK1T98PemdIWv1gD8mU14uNZJjjiZ1RBGiFObitrSqabiA_zp_XZRqOhknjzVP0ob8HM.; DOMAIN=labm3pcoe123");

	web_custom_request("ucmdb_browser.rpc_34", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t58.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|19|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|computed width: |1236|, computed height:|547|width: |1250|, height: |662|offset width: |, offset height:|1|2|3|4|2|5|6|TuEvv4n|6|7|1|"
		"8|0|7|6|9|10|9|11|9|12|9|13|9|14|9|15|9|16|9|17|9|18|-6|9|19|-8|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_35", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreviewCIProperties|java.lang.String/2004016611|384ec0c039021060e65e4422130509a8|1|2|3|4|1|5|6|", 
		LAST);

	web_add_cookie("LWSSO_COOKIE_KEY=W1mWNWbj_s_4YchkP1szoGAE3sKpB64sDkmnrECJ3Nua-rZabIN532biDlYd55DeuAbmbT1QWpiArLSpCKYoxyBZvUfMFlZYmGasnXglu2bJv_ba7_Epl8BDcKCRD4Z6Q3igEHvPnD6piUUDbcJCffaLDawYLH0AZEuXpiTB9kucl2M_8E3nA3yKN1dWo6OcwhwbWTf0ahrPQVjFWcnwhtwfd0BAXn0dygWPALOe4mc.; DOMAIN=labm3pcoe123");

	web_custom_request("ucmdb_browser.rpc_36", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|384ec0c039021060e65e4422130509a8|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_37", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t61.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|384ec0c039021060e65e4422130509a8|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_38", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t62.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getImpactCIsPreview|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.impact.ImpactSeverity/3147780506|384ec0c039021060e65e4422130509a8|1|2|3|4|2|5|6|7|6|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_39", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ciWasVisited|java.lang.String/2004016611|384ec0c039021060e65e4422130509a8|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_40", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForKey|java.lang.String/2004016611|history_ui_mode|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_41", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1250|, height: |563|offset width: |, offset height:|658|computed width: |, computed height:|1|2|3|4|2|5|6|TuEvwBw|6|7|1|8|0|7"
		"|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-11|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_42", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t66.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|23|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|width: |1250|, height: |565|offset width: |, offset height:|660|computed width: |, computed height:|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|1|2|3|4|2|5|6|TuEvwAd|6|7|6|8|0|7|6|9|10|9|11|9|12|9|13|9|14|-6|9|15|9|16|9|17|-6|9|18|-8|19|0|7|0|20|0|7|0|21|0|7|0"
		"|22|0|7|0|23|0|7|0|22|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_43", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t67.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsPreview|java.lang.String/2004016611|384ec0c039021060e65e4422130509a8|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_44", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t68.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getStakeholderDataModel|java.lang.String/2004016611|384ec0c039021060e65e4422130509a8|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_45", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t69.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|9|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getHistoryChangesCount|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.history.HistoryChangesFilter/622495879|Z|384ec0c039021060e65e4422130509a8|java.util.Date/3385151746|1|2|3|4|3|5|6|7|8|6|9|Tr0jPKC|9|TuEvwKC|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_46", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search;search-selection=384ec0c039021060e65e4422130509a8", 
		"Snapshot=t70.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostVisitedCIs|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_47", 
		"URL=http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://labm3pcoe123:8088/ucmdb-browser/?locale=en#search=0.0.0.110;tab=search", 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|36|http://labm3pcoe123:8088/ucmdb-browser/ucmdb_browser/|EF9660855520C7F57521D031D26EA6D1|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logStatistics|J|com.hp.ucmdb_browser.shared.statistics.UserStatisticContainer/293460140|java.util.HashMap/1797211028|com.hp.ucmdb_browser.shared.statistics.EventScope$TEST_STATISTICS/2395835662|java.lang.String/2004016611|computed width: |1237|, computed height:|547|width: |1236|, height: |offset width: |, offset height:|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$PROPERTIES_WIDGET/566157028|number_of_properties|3|com.hp.ucmdb_browser.shared.statistics.EventScope$IMPACT_WIDGET/1255057639|severity_count|[(Critical,2),(Low,0),(High,0),(Medium,4)]|com.hp.ucmdb_browser.shared.statistics.EventScope$HISTORY_WIDGET/3935775721|com.hp.ucmdb_browser.shared.statistics.EventScope$ENVIRONMENT_WIDGET/3886739767|groups|[(Location ,1),(JEE,1),(Database ,1),(Web Server ,1),(Infrastructure ,127),(Network ,3),(Other ,1)]|"
		"com.hp.ucmdb_browser.shared.statistics.EventScope$STAKEHOLDER_WIDGET/3845702|number_of_direct_stakeholders|1|number_of_indirect_stakeholders|0|maximum_daily_changes|minimum_daily_changes|number_of_days_with_changes|1|2|3|4|2|5|6|TuEvywJ|6|7|11|8|0|7|6|9|10|9|11|9|12|9|13|9|14|9|15|9|16|-8|9|17|-6|9|18|-8|19|1|7|0|19|3|7|1|9|20|9|21|22|1|7|0|22|3|7|1|9|23|9|24|25|1|7|0|26|1|7|0|26|3|7|1|9|27|9|28|29|1|7|0|29|3|7|2|9|30|9|31|9|32|9|33|25|3|7|3|9|34|-41|9|35|-41|9|36|-41|22|", 
		LAST);

	lr_end_transaction("Browser_ViewWindowsByIP",LR_AUTO);

	return 0;
}
