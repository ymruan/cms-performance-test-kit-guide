SearchWindowsByResource2()
{

	lr_start_transaction("Browser2_SearchWindowsByResource2");


	web_custom_request("ucmdb_browser.rpc_41", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t689.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ucmdbBrowserUserSearch|I|java.lang.String/2004016611|all windows running SQL server {lrSqlVersion}|com.hp.ucmdb_browser.client.search.NewSearchController@a79|1|2|3|4|3|5|6|6|25|7|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_42", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t690.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|25|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_43", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t691.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_44", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t692.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsUpdate|I|1|2|3|4|1|5|25|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_45", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t693.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsWithPaging|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|I|All results|1|2|3|4|2|5|6|5|7|16|0|25|25|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_46", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t694.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|25|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_47", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t695.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_48", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search;search=all%20windows%20running%20SQL%20server%20{lrSqlVersion}", 
		"Snapshot=t696.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|11|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|searchWithResults|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.SearchResultsInitialData/788401547|all windows running sql server {lrSqlVersion}|java.util.HashMap/1797211028|nt|java.lang.Integer/3438268394|Windows|1|2|3|4|2|5|6|7|6|8|1|5|9|10|1200|1|1|8|1|5|11|10|1200|25|0|0|1200|", 
		LAST);

	lr_end_transaction("Browser2_SearchWindowsByResource2",LR_AUTO);

	return 0;
}
