SearchSqlServerByAttribute()
{
	char *str = lr_eval_string("{lrSqlNameAndVersion}"); 
	char separators[] = "-";
    char* res = (char*)strtok(str,separators);
	
	if (res !=NULL) {
		lr_save_string(res,"lrSqlServerName");
	}else{
		lr_abort();
	}

	res = (char*)strtok(NULL,separators);
	if (res !=NULL) {
		lr_save_string(res,"lrSqlServerVersion");
	}else{
		lr_abort();
	}


	web_custom_request("ucmdb_browser.rpc_285", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t574.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.0|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_286", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t575.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|0.0.0|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_287", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t576.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|{lrSqlServerName}|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_288", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t577.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|{lrSqlServerName} with v|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_289", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t578.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|{lrSqlServerName} with version|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_290", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t579.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|{lrSqlServerName} with version 201|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_291", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t580.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchAutoCompleteOptions|java.lang.String/2004016611|{lrSqlServerName} with version {lrSqlServerVersion}|1|2|3|4|1|5|6|", 
		LAST);

	lr_start_transaction("Browser_SearchSqlServerByAttribute");

	web_custom_request("ucmdb_browser.rpc_292", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#tab=search", 
		"Snapshot=t581.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|ucmdbBrowserUserSearch|I|java.lang.String/2004016611|{lrSqlServerName} with version {lrSqlServerVersion}|com.hp.ucmdb_browser.client.search.NewSearchController@864|1|2|3|4|3|5|6|6|8|7|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_293", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t582.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|8|7|", 
		LAST);

	//web_add_cookie("LWSSO_COOKIE_KEY=i1Op5BkLA1WyszKHBLT2xqUVK4J6ROvjNNBlRGgDSNazeIItrGboWxl_iNf6lZxDhz7RjFcEkwQytw-gaMIqxTDUZYmBmst-RQm8dGEFxDY3FMvp3yvBdl4Qv2UbCmhfUxx4__CKKXq-WiNlMwWUIYFAtqOpwTQWrQpxmRD5aM_qToXqLJdr6rlejg7RvIrMHNDc0Ib05ojHQCMV7hFh3dpPT6L4CzfVUafTzrQqbvU.; DOMAIN={lrServerName}");

	web_custom_request("ucmdb_browser.rpc_294", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t583.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_295", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t584.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsWithPaging|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|I|All results|1|2|3|4|2|5|6|5|7|16|0|8|8|", 
		EXTRARES, 
		"Url=../icons/sqldb/sqldb_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_296", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t585.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsUpdate|I|1|2|3|4|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_297", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t586.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_298", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t587.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|8|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_299", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t588.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsUpdate|I|1|2|3|4|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_300", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t589.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_301", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t590.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|8|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_302", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t591.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsUpdate|I|1|2|3|4|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_303", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t592.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_304", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t593.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|filterResultsByClassType|I|java.lang.String/2004016611||1|2|3|4|2|5|6|8|7|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_305", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t594.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|7|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSearchResultsWithPaging|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|I|All results|1|2|3|4|2|5|6|5|7|16|0|8|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_306", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSqlServerName}%20with%20version%20{lrSqlServerVersion};tab=search", 
		"Snapshot=t595.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|13|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|searchWithResults|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.SearchResultsInitialData/788401547|{lrSqlServerName} with version {lrSqlServerVersion}|java.util.HashMap/1797211028|nt|java.lang.Integer/3438268394|sqlserver|Windows|SQL Server|1|2|3|4|2|5|6|7|6|8|2|5|9|10|6|5|11|-4|1|1|8|2|5|12|-4|5|13|-4|8|0|0|12|", 
		LAST);

	lr_end_transaction("Browser_SearchSqlServerByAttribute",LR_AUTO);

	return 0;
}
