Logout()
{

    if (strcmp(pLoginOnce,"true")==0)
	{
		return 0;
	}

	lr_start_transaction("Browser_Logout");

	web_url("logout.jsp", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/public/logout.jsp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/{lrUniqueValue2}.cache.html", 
		"Snapshot=t245.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_url("ucmdb_browser.jsp", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/public/logout.jsp", 
		"Snapshot=t246.inf", 
		"Mode=HTML", 
		LAST);

	web_url("{lrUniqueValue2}.cache.html_3", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/{lrUniqueValue2}.cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t247.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_18", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t248.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreLoginData|1|2|3|4|0|", 
		LAST);

	lr_end_transaction("Browser_Logout",LR_AUTO);

	return 0;
}