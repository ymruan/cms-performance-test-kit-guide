vuser_init()
{
	
	char* pSleep = NULL ;
    char* pServerName;
	char* pUniqueValue1 ;
	char* pUniqueValue2 ;

    pServerName = lr_get_attrib_string("ServerName");
	if (pServerName == NULL) {
		lr_error_message("ServerName parameter is missing");
		lr_abort();
	}
	lr_message("ServerName = %s",pServerName);
	lr_save_string(pServerName,"lrServerName");

	pUniqueValue1 = lr_get_attrib_string("UniqueValue1");
	if (pUniqueValue1 == NULL) {
		lr_error_message("UniqueValue1 parameter is missing");
		lr_abort();
	}
	lr_message("UniqueValue1 = %s",pUniqueValue1);
	lr_save_string(pUniqueValue1,"lrUniqueValue1");

	pUniqueValue2 = lr_get_attrib_string("UniqueValue2");
	if (pUniqueValue2 == NULL) {
		lr_error_message("UniqueValue2 parameter is missing");
		lr_abort();
	}
	lr_message("UniqueValue2 = %s",pUniqueValue2);
	lr_save_string(pUniqueValue2,"lrUniqueValue2");

	pLoginOnce = lr_get_attrib_string("LoginOnce");
	if (pLoginOnce == NULL) {
		pLoginOnce = (char*)malloc(5 * sizeof(char));
		strcpy(pLoginOnce,"true");
	}

	pSleep = lr_get_attrib_string("Sleep1");
	if (pSleep == NULL) {
		dbSleep1 = 30;
	}else{
		dbSleep1 = atoi(pSleep);
	}
	lr_message("Sleep1 = %f",dbSleep1);

	pSleep = lr_get_attrib_string("Sleep2");
	if (pSleep == NULL) {
		dbSleep2 = 30;
	}else{
		dbSleep2 = atoi(pSleep);
	}
	lr_message("Sleep2 = %f",dbSleep2);

	pSleep = lr_get_attrib_string("Sleep3");
	if (pSleep == NULL) {
		dbSleep3 = 30;
	}else{
		dbSleep3 = atoi(pSleep);
	}
	lr_message("Sleep3 = %f",dbSleep3);

	pSleep = lr_get_attrib_string("Sleep4");
	if (pSleep == NULL) {
		dbSleep4 = 30;
	}else{
		dbSleep4 = atoi(pSleep);
	}
	lr_message("Sleep4 = %f",dbSleep4);

	pSleep = lr_get_attrib_string("Sleep5");
	if (pSleep == NULL) {
		dbSleep5 = 30;
	}else{
		dbSleep5 = atoi(pSleep);
	}
	lr_message("Sleep5 = %f",dbSleep5);

	pSleep = lr_get_attrib_string("Sleep6");
	if (pSleep == NULL) {
		dbSleep6 = 30;
	}else{
		dbSleep6 = atoi(pSleep);
	}
	lr_message("Sleep6 = %f",dbSleep6);

	pSleep = lr_get_attrib_string("Sleep7");
	if (pSleep == NULL) {
		dbSleep7 = 30;
	}else{
		dbSleep7 = atoi(pSleep);
	}
	lr_message("Sleep7 = %f",dbSleep7);

	pSleep = lr_get_attrib_string("Sleep8");
	if (pSleep == NULL) {
		dbSleep8 = 30;
	}else{
		dbSleep8 = atoi(pSleep);
	}
	lr_message("Sleep8 = %f",dbSleep8);
	return 0;
}
