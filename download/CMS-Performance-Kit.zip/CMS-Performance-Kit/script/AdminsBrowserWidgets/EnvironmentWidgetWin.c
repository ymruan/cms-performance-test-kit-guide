EnvironmentWidgetWin()
{
	lr_start_transaction("Browser_EnvironmentWidget");


	web_url("7.cache.js", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/deferredjs/{lrUniqueValue2}{lrUniqueValue2}/7.cache.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", 
		"Snapshot=t116.inf", 
		LAST);

	
	web_custom_request("ucmdb_browser.rpc_45", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", 
		"Snapshot=t120.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=UTF-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue2}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForEnvironmentWidgetForKey|java.lang.String/2004016611|ENVIRONMENT_WIDGET_MODE|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_46", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", 
		"Snapshot=t121.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=UTF-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue2}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForEnvironmentWidgetForKey|java.lang.String/2004016611|ENVIRONMENT_WIDGET_CI_LIST_VIEW_STATE|1|2|3|4|1|5|6|", 
		LAST);

	//web_add_cookie("ENVIRONMENT_WIDGET_MODE=Map; DOMAIN={lrServerName}");

	web_custom_request("ucmdb_browser.rpc_47", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", 
		"Snapshot=t122.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=UTF-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue2}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|saveUserPreferencesForEnvironmentWidgetForKey|java.lang.String/2004016611|java.util.ArrayList/4159755760|ENVIRONMENT_WIDGET_MODE|Map|1|2|3|4|2|5|6|7|6|1|5|8|", 
		LAST);

	//web_add_cookie("ENVIRONMENT_WIDGET_CI_LIST_VIEW_STATE=hidden; DOMAIN={lrServerName}");

	web_custom_request("ucmdb_browser.rpc_48", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", 
		"Snapshot=t123.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=UTF-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue2}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|saveUserPreferencesForEnvironmentWidgetForKey|java.lang.String/2004016611|java.util.ArrayList/4159755760|ENVIRONMENT_WIDGET_CI_LIST_VIEW_STATE|hidden|1|2|3|4|2|5|6|7|6|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_49", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", 
		"Snapshot=t124.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=UTF-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue2}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsExpanded|java.lang.String/2004016611|{lrWindowsID}|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=../icons/it_world/it_world_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/sqldb/sqldb_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/app/app_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/webserver/webserver_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/logical_application/logical_application_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/software/software_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/interface/interface_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/process/process_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/port/port_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/hostresource/hostresource_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/service/service_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/ip/ip_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/system/system_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/network/network_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/logical_owner/logical_owner_16.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_50", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", 
		"Snapshot=t125.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=UTF-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue2}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getEnvironmentWidgetDeployedQueryName|java.lang.String/2004016611|{lrWindowsID}|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=../icons/it_world/it_world_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/logical_application/logical_application_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/software/software_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/interface/interface_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/port/port_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/process/process_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/hostresource/hostresource_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/service/service_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/ip/ip_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/system/system_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/network/network_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../icons/logical_owner/logical_owner_32.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);


	web_custom_request("ucmdb_browser.rpc_51",
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en",
		"Snapshot=t129.inf",
		"Mode=HTML",
		"EncType=text/x-gwt-rpc; charset=UTF-8",
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue2}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSelectedContextNodeId|java.lang.String/2004016611|{CorrelationParameter}|1|2|3|4|1|5|6|",
		EXTRARES,
		"URL=../TopologyVisualization/getImage?zoom=1&col=2&row=-1&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=1&row=0&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=3&row=-2&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=2&row=1&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=0&row=0&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=2&row=0&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=3&row=-1&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=3&row=0&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		"URL=../TopologyVisualization/getImage?zoom=1&col=3&row=1&size=512&path={CorrelationParameter}&seq=e6ba4d60-af3a-11e3-9b03-9c48628c0964", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM,
		LAST);


	lr_end_transaction("Browser_EnvironmentWidget",LR_AUTO);

	return 0;

/*	
	lr_start_transaction("Browser2_EnvironmentWidgetWin");

	web_custom_request("ucmdb_browser.rpc_78", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t1254.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getRelatedCIsExpanded|java.lang.String/2004016611|{lrWindowsID}|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_79", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t1255.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getEnvironmentWidgetDeployedQueryName|java.lang.String/2004016611|{lrWindowsID}|1|2|3|4|1|5|6|", 
		LAST);

	web_submit_data("loadCmdbQuery_3", 
		"Action=http://{lrServerName}:8088/ucmdb-browser/TopologyVisualization/actions/loadCmdbQuery", 
		"Method=POST", 
		"RecContentType=text/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t1256.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=queryName", "Value=MIZI_ENVIRONMENT_FOR_MAP_WITH_LOCAL_DATA_STORE", ENDITEM, 
		"Name=layout", "Value=classification", ENDITEM, 
		"Name=selectedCi", "Value={lrWindowsID}", ENDITEM, 
		"Name=idsRestrictions", "Value=[\"{lrWindowsID}\"]", ENDITEM, 
		LAST);

	web_submit_data("loadGraph_3", 
		"Action=http://{lrServerName}:8088/ucmdb-browser/TopologyVisualization/loadGraph", 
		"Method=POST", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=path", "Value=TopologyGraph", ENDITEM, 
		EXTRARES, 
		"Url=getWorldBounds?path=TopologyGraph&seq=bab242c0-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", ENDITEM, 
		"Url=getHierarchyInfo?path=TopologyGraph&dojo.preventCache=1382447174118", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", ENDITEM, 
		LAST);

	web_submit_data("getElementBounds_3", 
		"Action=http://{lrServerName}:8088/ucmdb-browser/TopologyVisualization/getElementBounds?path=TopologyGraph&x=0&y=-38&width=1391&height=323&types=5", 
		"Method=POST", 
		"RecContentType=text/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t1257.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		EXTRARES, 
		"Url=getImage?zoom=1&col=0&row=-1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=0&row=-2&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=0&row=1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=1&row=-2&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=1&row=-1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=1&row=1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=0&row=0&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=getImage?zoom=1&col=2&row=-2&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_80", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t1258.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSelectedContextNodeId|java.lang.String/2004016611|TopologyGraph|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=1&row=0&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=2&row=-1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=2&row=0&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../TopologyVisualization/getImage?zoom=1&col=2&row=1&size=512&path=TopologyGraph&seq=bae1b730-3b1a-11e3-ae16-9442f6630f5b", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	lr_end_transaction("Browser2_EnvironmentWidgetWin",LR_AUTO);

	return 0;
	*/
}