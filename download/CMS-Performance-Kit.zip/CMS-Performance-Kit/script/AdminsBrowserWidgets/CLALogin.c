CLALogin()
{
	
char *str = lr_eval_string("{pUserList}"); 
	char separators[] = "_";
    char* res = (char*)strtok(str,separators);
	
	if (res !=NULL) {
		lr_save_string(res,"pUserType");
	}else{
		lr_abort();
	}

	lr_start_transaction(lr_eval_string("{pUserType}"));

	web_custom_request("ucmdb_browser.rpc_2", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|10|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|login|java.lang.String/2004016611|J|Z|{pUserList}|test|Default Client|1|2|3|4|5|5|5|5|6|7|8|9|10|P__________|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_3", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUCMDBUserLocale|1|2|3|4|0|", 
		EXTRARES, 
		"Url=deferredjs/5DBC405ED487BD083B01CEB28A78CD11/20.cache.js", "Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", ENDITEM, 
		"Url=deferredjs/5DBC405ED487BD083B01CEB28A78CD11/1.cache.js", "Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_4", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForEnvironmentWidgetForKey|java.lang.String/2004016611|SEARCH_MODE|1|2|3|4|1|5|6|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_5", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostVisitedCIs|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_6", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getMostSearchedPhrases|1|2|3|4|0|", 
		EXTRARES, 
		"Url=deferredjs/5DBC405ED487BD083B01CEB28A78CD11/3.cache.js", "Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_7", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getIntegerConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_8", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getIntegerConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|2|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_9", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getIntegerConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_10", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|readUserNotificationCount|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_11", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getIntegerConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_12", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getCategories|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_13", 
		"URL=http://mydph0165:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://mydph0165:8088/ucmdb-browser/ucmdb_browser.jsp#tab=search", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://mydph0165:8088/ucmdb-browser/ucmdb_browser/|2C031F778C3C3876D4B4EB18A340680B|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getStringConfigParameterValue|com.hp.ucmdb_browser.shared.constants.SettingNames/2795573392|1|2|3|4|1|5|5|7|", 
		LAST);
		
lr_end_transaction(lr_eval_string("{pUserList}"),LR_AUTO);
	return 0;
}