Login_br4_1()
{
	 int result;
	if (strcmp(pLoginOnce,"true")==0)
	{
		if (fLoginDone == 1)
		{
			return ;
		}
		else
		{
			fLoginDone = 1;
		}
	}

	lr_start_transaction("Browser_Login");

	web_add_cookie("ucmdb-theme=HP_EXPERIENCE; DOMAIN={lrServerName}");

	

	web_custom_request("ucmdb_browser.rpc_2", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|10|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|login|java.lang.String/2004016611|J|Z|admin|Default Client|e821ec85a507f92db544f1e6cb52cfd2|1|2|3|4|6|5|5|5|6|7|5|8|8|9|P__________|0|10|", 
		LAST);

	web_url("ucmdb_browser.jsp_2", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default%20Client&locale=en", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/{lrUniqueValue2}.cache.html", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("{lrUniqueValue2}.cache.html_2", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/{lrUniqueValue2}.cache.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_3", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getPreLoginData|1|2|3|4|0|", 
		EXTRARES, 
		"Url=deferredjs/{lrUniqueValue2}/19.cache.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=deferredjs/{lrUniqueValue2}/1.cache.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/complete.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=deferredjs/{lrUniqueValue2}/4.cache.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=clear.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=base/images/grid/grid3-hd-btn.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/lang.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-layout-bridge.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/core-lib.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/core-lib.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/algorithms.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/algorithms.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-util.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-util.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-core.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-core.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/canvas-core.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_4", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferences|java.lang.String/2004016611|SEARCH_MODE|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=../yfiles-js/yfiles/graph-layout-bridge.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/canvas-core.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/complete.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=deferredjs/{lrUniqueValue2}/3.cache.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-base.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-base.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_5", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getBulkReports|1|2|3|4|0|", 
		EXTRARES, 
		"Url=../yfiles-js/yfiles/layout.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-circular.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-circular.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-organic.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-organic.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/complete.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-hierarchic.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=deferredjs/{lrUniqueValue2}/2.cache.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-hierarchic.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-router.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-router.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-tree.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-tree.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_6", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getDashboardModel|1|2|3|4|0|", 
		EXTRARES, 
		"Url=deferredjs/{lrUniqueValue2}/5.cache.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-misc.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-misc.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-multipage.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-multipage.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-partial.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-partial.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-orthogonal.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-orthogonal.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-planar.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-planar.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-polyline.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-polyline.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/viewer.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/viewer.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-binding.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-binding.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-folding.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-folding.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-graphml.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-graphml.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-input-table.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-input-table.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-input.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_7", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|readUserNotificationCount|1|2|3|4|0|", 
		EXTRARES, 
		"Url=../yfiles-js/yfiles/graph-input.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-table.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-table.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-control.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-control.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-defaults.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-defaults.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-extra.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-extra.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-simple.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-simple.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-table.impl.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/core-lib.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-table.mapping.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-circular.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-core.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-hierarchic.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-multipage.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-partial.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-misc.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-planar.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-router.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-tree.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/canvas-core.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-base.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-polyline.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-binding.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-control.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-input.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-table.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-defaults.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-extra.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-table.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/algorithms.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-orthogonal.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-layout-bridge.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-organic.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-graphml.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/viewer.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-input-table.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-style-simple.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/graph-folding.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		"Url=../yfiles-js/yfiles/layout-util.js", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_8", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|updateUserNotification|I|com.hp.ucmdb_browser.shared.notifications.UserNotificationFilter/241703918|1|2|3|4|2|5|6|1|6|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_9", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserNotification|I|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|com.hp.ucmdb_browser.shared.notifications.UserNotificationFilter/241703918|UNREAD|1|2|3|4|3|5|6|7|1|6|8|16|0|1|7|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_10", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserNotification|I|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|com.hp.ucmdb_browser.shared.notifications.UserNotificationFilter/241703918|UNREAD|1|2|3|4|3|5|6|7|1|6|8|16|0|1|7|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_11", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getSessionTimeout|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_12", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|5|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|modelingGetTemplates|java.lang.String/2004016611|1|2|3|4|1|5|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_13", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|4|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getNewServiceModelFormData|1|2|3|4|0|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_14", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserNotification|I|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|com.hp.ucmdb_browser.shared.notifications.UserNotificationFilter/241703918|UNREAD|1|2|3|4|3|5|6|7|1|6|8|16|0|1|7|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_15", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserNotification|I|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|com.hp.ucmdb_browser.shared.notifications.UserNotificationFilter/241703918|UNREAD|1|2|3|4|3|5|6|7|1|6|8|16|0|1|7|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_16", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserNotification|I|com.hp.ucmdb_browser.shared.search.PagingInfo/348128909|com.hp.ucmdb_browser.shared.notifications.UserNotificationFilter/241703918|UNREAD|1|2|3|4|3|5|6|7|1|6|8|16|0|1|7|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_17", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|18|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|logRPC|java.util.List|java.util.ArrayList/4159755760|com.hp.ucmdb_browser.shared.rpc_manager.RPCCallEntry/2191371440|getPreLoginData - MainEntryPoint|java.util.Date/3385151746|getUserPreferences - SearchWithResultsWidget|getBulkReports - ReportsChooserPanel|getDashboardModel - DashboardModelController|readUserNotificationCount - NotificationController|"
		"updateUserNotification - NotificationResultController|getUserNotification - NotificationResultController|getSessionTimeout - MainEntryPoint|getNewServiceModelFormData - CreateNewServiceDataController|modelingGetTemplates - ModelingTemplatesDropdown|1|2|3|4|1|5|6|21|7|0|A|8|9|UzAvH2I|0|7|9|UzAvH6o|A|8|-3|1|7|0|B|10|9|UzAvIq7|0|7|0|C|11|9|UzAvIu$|0|7|9|UzAvIz_|B|10|-7|1|7|0|D|12|9|UzAvI1g|0|7|9|UzAvI2c|C|11|-9|1|7|0|E|13|9|UzAvI6W|0|7|9|UzAvI_M|D|12|-13|1|7|0|F|14|9|UzAvJRr|0|7|0|G|15|9|UzAvJVr|0|7|"
		"0|H|15|9|UzAvJsa|0|7|9|UzAvJs_|E|13|-17|1|7|9|UzAvJtB|F|14|-21|1|7|9|UzAvJtP|G|15|-23|1|7|9|UzAvJti|H|15|-25|1|7|0|I|16|9|UzAvJv5|0|7|9|UzAvJwO|I|16|-35|1|7|0|J|17|9|UzAvJx9|0|7|0|K|18|9|UzAvJ0o|0|7|9|UzAvJ07|K|18|-41|1|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_18", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?server=Default Client&locale=en#tab=search", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferences|java.lang.String/2004016611|modeling_template_last_selected|1|2|3|4|1|5|6|", 
		LAST);

	lr_end_transaction("Browser_Login",LR_AUTO);
	
	result = web_get_int_property(HTTP_INFO_RETURN_CODE);
	lr_message("result = %d",result);
	if (result!=200 && result != 202) {
		lr_error_message("Login Failed,Aborting user");
		lr_abort();
	}



	return 0;
}