HistoryWidgetWin()
{

	lr_start_transaction("Browser_HistWidgetWin");
	
	web_url("19.cache.js", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/deferredjs/{lrUniqueValue2}/19.cache.js", 
		"Resource=1", 
		"RecContentType=application/javascript", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t973.inf", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_45", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t974.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|6|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getUserPreferencesForKey|java.lang.String/2004016611|history_ui_mode|1|2|3|4|1|5|6|", 
		EXTRARES, 
		"Url=../gxt/themes/slate/images/slate/grid/grid3-hd-btn.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		"Url=../gxt/themes/slate/images/slate/grid/grid3-hrow.gif", "Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en", ENDITEM, 
		LAST);

	web_custom_request("ucmdb_browser.rpc_46", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t975.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|setUserPreferenceForKey|java.lang.String/2004016611|java.util.ArrayList/4159755760|history_date_from|1381788000784|1|2|3|4|2|5|6|7|6|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_47", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t976.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|8|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|setUserPreferenceForKey|java.lang.String/2004016611|java.util.ArrayList/4159755760|history_date_to|1382436021784|1|2|3|4|2|5|6|7|6|1|5|8|", 
		LAST);

	web_custom_request("ucmdb_browser.rpc_48", 
		"URL=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/ucmdb_browser.rpc", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser.jsp?locale=en#search={lrSelectedWindows};tab=search;search-selection={lrWindowsID}", 
		"Snapshot=t977.inf", 
		"Mode=HTML", 
		"EncType=text/x-gwt-rpc; charset=utf-8", 
		"Body=7|0|9|http://{lrServerName}:8088/ucmdb-browser/ucmdb_browser/|{lrUniqueValue1}|com.hp.ucmdb_browser.shared.UcmdbBrowserService|getHistoryChanges|java.lang.String/2004016611|com.hp.ucmdb_browser.shared.history.HistoryChangesFilter/622495879|Z|{lrWindowsID}|java.util.Date/3385151746|1|2|3|4|4|5|6|7|7|8|6|9|UG4$6IQ|9|UHfm6YY|0|1|", 
		LAST);

	lr_end_transaction("Browser_HistWidgetWin",LR_AUTO);

	return 0;
}