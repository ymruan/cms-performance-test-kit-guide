Sleep2()
{
	lr_think_time(dbSleep2);
	return 0;
}
