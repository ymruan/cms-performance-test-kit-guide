/*
 * LoadRunner Java script. (Build: 3020)
 * 
 * Script Description: 
 *                     
 */

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import com.hp.ucmdb.pcoe.utils.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import com.hp.cmdb.pcoe.urmtesting.URMTester; 

import com.hp.ucmdb.api.UcmdbService;
import com.hp.ucmdb.api.UcmdbServiceFactory;
import com.hp.ucmdb.api.UcmdbServiceProvider;
import com.hp.ucmdb.api.topology.*;
import com.hp.ucmdb.api.view.View;
import com.hp.ucmdb.api.view.ViewFolder;
import com.hp.ucmdb.api.view.ViewService;
import com.hp.ucmdb.api.view.ViewWithFoldingDefinition;
import com.hp.ucmdb.api.view.foldingdefinition.FoldingDefinition;
import com.hp.ucmdb.api.view.foldingdefinition.FoldingDefinitionNodesFactory;
import com.hp.ucmdb.api.view.foldingdefinition.GroupByTypeSyntheticFDN;

import java.net.MalformedURLException;


import lrapi.lr;

public class Actions {
	
   private int m_nSleepTime;
   private String m_sServerName = null ;
   private URMTester m_UrmTester = null ;
   private String m_sStuckOnFail = "false";
   private String m_sAbortOnFail = "true";
   private String m_sMailOnFail = "";
   private String m_sSkip = "false";
   private ArrayList<Map<String, String>> m_ListOfAttributesMap = new ArrayList<Map<String, String>>();

	
	public int init() throws Throwable {
		
	openXML("SystemTest_URM_ManageViews", "CommandLine");
	m_sSkip = getAttribute(0,"Skip", false, "false");
	if (m_sSkip.equals("true")) {
	    return 0;
	}

	 m_sStuckOnFail = getAttribute(0,"StuckOnFail", false, "false");//"true"\"false"
	 lr.message("StuckOnFail = " + m_sStuckOnFail);

	 m_sAbortOnFail = getAttribute(0,"AbortOnFail", false, "true");//"true"\"false"
	 lr.message("AbortOnFail = " + m_sAbortOnFail);

	 m_sMailOnFail = getAttribute(0,"MailOnFail", false, "");//"asaf@hp.com.ilevy@hp.com"
	 lr.message("MailOnFail = " + m_sMailOnFail);
	    
	 m_sServerName = getAttribute(0,"ServerName", true, null);//"asaf@hp.com.ilevy@hp.com"
	 lr.message("ServerName = " + m_sServerName);
	 
	 m_nSleepTime = Integer.valueOf(getAttribute(0,"SleepTime",true,"8"));
	 lr.message("SleepTime = "+ m_nSleepTime);
	    
     m_UrmTester = new URMTester();

	 if (!m_UrmTester.open(m_sServerName,8080,"admin","admin")) {
		System.out.println("Failed to open connection to server");
		return -1;
	    }

	    return 0;
	}//end of init


	public int action() throws Throwable {

        m_UrmTester.createView("SystemTestView" + lr.eval_string("<Vuser>"));

        lr.start_transaction("SaveViewInUrm");
		if (m_UrmTester.saveView()==true)
		lr.end_transaction("SaveViewInUrm",lr.PASS);
		else
		lr.end_transaction("SaveViewInUrm",lr.FAIL);

		lr.think_time((int)m_nSleepTime);

		m_UrmTester.attachViewToFolder();
                m_UrmTester.updateView() ;

               lr.start_transaction("UpdateViewInUrm");
		if (m_UrmTester.saveView()==true)
		    lr.end_transaction("UpdateViewInUrm",lr.PASS);
		else
		    lr.end_transaction("UpdateViewInUrm",lr.FAIL);

		lr.think_time((int)m_nSleepTime);

                lr.start_transaction("DeleteViewInUrm");
		if (m_UrmTester.deleteView("SystemTestView" + lr.eval_string("<Vuser>"))==true)
		    lr.end_transaction("DeleteViewInUrm",lr.PASS);
		else
		    lr.end_transaction("DeleteViewInUrm",lr.FAIL);

		
                return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end

    private String getAttribute(int nCommandLine,String attrName,boolean failIfNull,String defaultValue){
 if (m_ListOfAttributesMap.size()> nCommandLine)
 {
     Map<String,String> map = m_ListOfAttributesMap.get(nCommandLine);
     if (map.containsKey(attrName)) {
	 lr.message("Attribute : " + attrName + " appears in XML");
	 return map.get(attrName);
     }else{
	 if (failIfNull == true) {//in case a default value is no good
	     lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
	     sendMailOnFail("Error:SystemTest_URM_ManageViews","Attribute : " + attrName + " is mandatory.It does not appear in XML.ABORTING");
	     stuckOnFail();
	     lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	     return "";
	 } else {//in case we can use a default value
	     if (defaultValue != null) {//there IS a default value
		 lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,Using default value");
		 return defaultValue;
	     } else {//no default value
		 lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
		 sendMailOnFail("Error:SystemTest_URM_ManageViews","Attribute : " + attrName + " is not mandatory.It does not appear in XML ,But there is no default value.ABORTING");
		 stuckOnFail();
		 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
		 return "";
	     }
	 }
     }
 }else{
     return checkStringAttr(attrName,failIfNull,defaultValue);
 }
}


private String checkStringAttr(String attrName, boolean failIfNull, String defaultValue) {
 if (!(attrName == null)) {//we have an attribute name
     String attr = lr.get_attrib_string(attrName);
     if (attr == null) {//no param value
	 if (failIfNull == true) {//in case a default value is no good
	     lr.error_message("Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
	     sendMailOnFail("Error:SystemTest_URM_ManageViews","Attribute : " + attrName + " is mandatory.It does not appear in command line.ABORTING");
	     stuckOnFail();
	     lr.exit(lr.EXIT_VUSER, lr.FAIL); 
	     return "";
	 } else {//in case we can use a default value
	     if (defaultValue != null) {//there IS a default value
		 lr.message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,Using default value");
		 return defaultValue;
	     } else {//no default value
		 lr.error_message("Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
		 sendMailOnFail("Error:SystemTest_URM_ManageViews","Attribute : " + attrName + " is not mandatory.It does not appear in command line ,But there is no default value.ABORTING");
		 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
		 return "";
	     }
	 }
     } else {//we have param value
	 lr.message("Attribute : " + attrName + " appears in command line");
	 return attr;
     }
 } else {//we DONT have an attribute name at all
     lr.error_message("No attribute name supplied. Aborting VUser.");
     sendMailOnFail("Error:SystemTest_URM_ManageViews","No attribute name supplied. Aborting VUser.");
     stuckOnFail();
     lr.exit(lr.EXIT_VUSER, lr.FAIL); 
     return "";
 }
}

	
	private void openXML(String sScriptName,String sCommandLine){
 String sSettingsXML = checkStringAttr("SettingsXML", false, "");
 lr.message("SettingsXML file : " + sSettingsXML);
 Map<String, String> attributes ;
 if (!sSettingsXML.isEmpty()) {
     try{
      XmlReader xmlReader = new XmlReader();
      xmlReader.open(sSettingsXML);
      attributes = xmlReader.getAttributes(sScriptName,sCommandLine);
      if (attributes == null)   {
	 lr.error_message("Parameter SettingsXML supplied but attributes was not found");
	 sendMailOnFail("Error:SystemTest_URM_ManageViews","Parameter SettingsXML supplied but attributes was not found");
	 stuckOnFail();
	 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
      }else{
	  m_ListOfAttributesMap.add(attributes);
	  while((attributes = xmlReader.getNextAttributes())!=null){
	       m_ListOfAttributesMap.add(attributes);
	  }
      }
     }catch(Exception e){
	 lr.error_message("Exception occured during reading SettingsXML");
	 lr.error_message(e.getMessage());
	 sendMailOnFail("Error:SystemTest_URM_ManageViews","Exception occured during reading SettingsXML\n"+e.getMessage());
	 stuckOnFail();
	 lr.exit(lr.EXIT_VUSER, lr.FAIL); 
     }
 }else{
     lr.message("SettingsXML file does not appear in command line, trying to get all attributes from command line");
 }
}

private void sendMailOnFail(String sSubject,String sMessage){
 if (m_sMailOnFail.equals(""))
     return ;
 MailSender mailSender = new MailSender();
 mailSender.sendMail("smtp3.hp.com",m_sMailOnFail,m_sMailOnFail, sSubject, sMessage);
}

private void stuckOnFail(){
 if (m_sStuckOnFail.toLowerCase().equals("true")) {
     while(true){
	 lr.think_time(1);
     }
 }
}

private void abortOnFail(){
 if (m_sAbortOnFail.toLowerCase().equals("true")) {
   lr.exit(lr.EXIT_VUSER, lr.FAIL); 
 }
}
	
}
