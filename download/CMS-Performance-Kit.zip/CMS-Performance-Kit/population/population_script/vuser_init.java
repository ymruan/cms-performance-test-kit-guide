// Do not change this file
/*
 * uCMDB_90_Population_tool_01
 * 
 * Script Description: 
 * Script Author: Eran Brand (PCoE)
 *                     
 */
//
// Do not change this file
/****************************************************************************************
*											*
*                                   MERCURY						*
*											*
*                       Performance Center Of Excellence				*
*											*
*		Author: Eran Brand, PCoE ET. July 2010. eran.brand@hp.com		*
*											*
*****************************************************************************************
*				Script overview						*
*****************************************************************************************
*											*
*	Product:			UCMDB                       			*
*	Product Version:		 9.0						*
*											*
*	Script Author: 		Eran Brand, PCoE ET					*
*	Creation Date:		07/2010							*
*											*
*	Reviewed by	 :								*
*	Review date  : 									*
*											* 
*****************************************************************************************
*											*
*	Business Process Name: uCMDB_90_Population_tool_01  				*
*											*
*	General Business Process Description:	                                        *
*   	This flow is the uCMDB 9.0 data in flow. It's meant for populating the uCMDB 9.0*
*    	moidel and not updating or deleting CIs. It inserts CIs, based on a graph of 	*
*    	about 25 diferent CITs. The insertion action is wrapped by a (measurable) 	*
*	transaction.									*
*    	  										*
*****************************************************************************************
*	General explenation:								*										*
*=======================================================================================*
*	General usage:									*									
*	The data is added to the model in bulks. For each bulk in the standard bulk size*
*	(20K objects and links) 70 IPs are entered. If you change the amount of host 	*
*	added in each bulk to X, X IPs will be added. If you want 1M CIs + links, you	*
*	need 50 bulks (1M/20K=50). Each bulk consists of 70 IPs so your range size is	*
*	3,500 (50 bulks * 70 IPs in each bulk = total of 3,500 IPs). So if you begin	*
*	population from scratch, your ipStart param should be 1, and your ipEnd should	*
*	be 3,500. If you do not begin from scratch, and you have say 1M in the model,	*
*	you already have IPs 1 to 3,500 (the int equivalent of course), so now your 	*
*	ipStart param should be 3,600 (just to be sure you don't overlap), and your 	*
*	ipEnd should be 7,200. *
*	Multiple customers:								*
*	If for any reason you want to add CIs to different customrs, use the 		*
*	CustomerName param with the customer you'd like to add CIs to, and do it for 	*
*	each customer separately. If you want to add the same ranges for multiple	*
*	customers, BE SURE to understand when identical CIs (except for customer name) 	*
*	merge and when they don't.							*
*****************************************************************************************
*											*
*	The amonut of data added:							*
*=======================================================================================*
*	The size of the trees is a factor of the 5 params in the INI file. It's 	*
*	recomended not to change the amounts and to stay with our standard bulk of 20K	*
*	objects and links. If you do want to edit the file, take a look at the topology *
*	graph at									*
*	\\illabstore01.devlab.ad\users\pcoe\UCMDB\YourINIs\SNMP_topology_graph.bmp	*
*	to understand what the INI CITs stand for. For instance, if instead of adding	*
*	SNMPHosts=70 you add SNMPHosts=140, you will multiply the amount of hosts added	*
*	by 2 and hence all the CITs connected to them (IPs, win users...).		*
* 	In general, don't add too large data bulks. Max should be 20K.			*
*											*
*****************************************************************************************
* The INI file:										*
* The INI file: is build in the usual way. A title and a few params:			*
*											*
*	[CITs]										*
*	SNMPTopologoy									*
*	SNMPHosts=70									*
*	SNMPProcs=50									*
*	SNMPWinUsrs=5									*
*	SNMPInstSWs=30									*
*	SNMPWinSrvcs=40									*
*											*
*	The most important param is the SNMPHosts. All the others are beneath it, 	*
*	meaning that if we have 2 hosts and 2 procs (processes) under each one, we'll 	*
*	have 4 prcesses. To better understand the CIs you're adding to the model, take a*
*	look at: 									*
*	\\illabstore01.devlab.ad\users\pcoe\UCMDB\YourINIs\SNMP_topology_graph.bmp	*
*****************************************************************************************
*											*
* Commandline Parameters:								*
* ======================								*
*	Mnadatory:									*
* ServerName - the uCMDB server to work against. The script fails if none is supplied	*
* ipStart - what IP to begin the IP range with. This is supplied as an int and the IP	*
*	itself will be the equivalent: 1 => 0.0.0.1, 257 => 0.0.1.2, etc'. No default	*
*	value. The script fails if none is supplied					*
* ipEnd - As in ipStart, the int equivalent to the upper bound of the IP range. The 	*
*	script fails if none is supplied						*
* INI - the INI file to read the params from, the params that determine the size of the *
*	the bulks added to the model. It is recomended to use the one supplied here and *
*	have the standard bulks of 20 K objects and links. The script fails if no INI 	*
*	file is supplied.								*
*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*
*!!!!!!!IMPORTANT - IMPORTANT - IMPORTANT!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*
*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*
*!!!!!!!DO NOT USE SOMEBODY ELSE'S INI, NEEDLESS TO SAY - DON'T EDIT IT.!!!!!!!!!!!!!!!!*
*!!!!!!!HAVE A COPY OF YOUR OWN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*
*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*
*	Optional:									*
* CustomerName - the name of the customer to add CIs to. Default value: "Default Client"*
*	which is equivalent to customer 1. Use it only if you need to add CIs to 	*
*	multiple customers								*
*											*
Commandline example (withOUT customer name)
-ServerName labm3pcoe129.devlab.ad -INI \\\\illabstore01.devlab.ad\\users\\pcoe\\UCMDB\\YourINIs\\PopTool90.ini -ipStart 1 -ipEnd 700
Commandline example (with customer name)
-ServerName labm3pcoe129.devlab.ad -INI \\\\illabstore01.devlab.ad\\users\\pcoe\\UCMDB\\YourINIs\\PopTool90.ini -ipStart 1 -ipEnd 700 -CustomerName CustomerXYZ

*****************************************************************************************
* Classpath:										*
* =========										*
* The following enteries need to be added to the class path:				*
* 1] PopTool90MultCustomers.jar the code that contains the logic. Currently (07/10) 	*
*	it's located at:								*
*	\\illabstore01.devlab.ad\users\pcoe\UCMDB\JARS\90PopTool\PopTool90MultCustomers.jar*			*
* 2] api-interfaces.jar The JAR supplied by uCMDB, the one that exposes the SDK. Take it*
*	from the installation dir, under lib folder.				        *
* 											*
* 											*
* 											*
*****************************************************************************************/





/****************************************************************************************
*			Script history							*
*****************************************************************************************
*											*
*	Modification Date: 07/2010							*
*											*
*	Author: Eran Brand 	   							*
*											*
*	Description:		   							*
*****************************************************************************************
*											*
*	Modification Date:    								*
*											*
*	Author:				  						*
*											*
*	Description:									*
*											*
*											*
*											*
****************************************************************************************/



