/*
 * LoadRunner Java script. (Build: 3020)
 * 
 * Script Description: 
 * Script Author: Eran Brand (PCoE)
 *                     
 */

import java.util.Date;

import com.hp.ucmdb.pcoe.population.*;

import lrapi.lr;


public class Actions
{
	private int m_CIsPerBulk;
	private int m_ipCount ;
	private String m_sStartIP ;
	private int m_hostNum;
        private String m_iniFile ;
	private int m_MarkCIsInterval;
	private int m_MarkStartVal;
	private int m_CIsToMarkForTQLs;
        private ConnectionProperties m_conProp;
        private PopulationProperties m_popProp;

	public int init() throws Throwable {
            m_conProp = new ConnectionProperties();
	    m_conProp.HOST = checkStringAttr("ServerName",true,null);//uCMDB machine
	    lr.message("HOST - " + m_conProp.HOST);
            m_conProp.CUSTOMER = checkStringAttr("CustomerName",false,"Default Client");
	    lr.message("CUSTOMER - " + m_conProp.CUSTOMER);
            m_conProp.USER_NAME = checkStringAttr("UserName",false,"admin");
	    lr.message("USER_NAME  - " + m_conProp.USER_NAME);
            m_conProp.PASSWORD = checkStringAttr("Password",false,"admin");
	    lr.message("PASSWORD  - " + m_conProp.PASSWORD);

	    m_MarkCIsInterval = Integer.valueOf(checkStringAttr("MarkInterval",false,"1000000"));
	    lr.message("MarkCIsInterval - "+ m_MarkCIsInterval);
	    m_MarkStartVal = Integer.valueOf(checkStringAttr("MarkStartVal",false,"1"));
	    lr.message("MarkStartVal - "+ m_MarkStartVal);

	    m_sStartIP = checkStringAttr("StartIP",true,null);
	    lr.message("StartIP - "+ m_sStartIP);
            int CIsToAdd = Integer.parseInt(checkStringAttr("CIsToAdd",true,null));
	    lr.message("CIsToAdd - "+ CIsToAdd);
	    m_CIsToMarkForTQLs = Integer.parseInt(checkStringAttr("CIsToMarkForTQLs",true,null));
	    lr.message("CIsToMarkForTQLs - "+ m_CIsToMarkForTQLs);

	    m_iniFile = checkStringAttr("INI",true,null);
	    lr.message("iniFile - "+ m_iniFile);
            m_popProp = new PopulationProperties(m_iniFile);

            m_hostNum = m_popProp.getSNMPHostNum();
            int procNum = m_popProp.getSNMPProcNum();
            int winUserNum = m_popProp.getSNMPWinUsrNum();
            int instSWNum = m_popProp.getSNMPInstSWNum();
            int winSrvNum = m_popProp.getSNMPWinSrvcNum();

	    m_CIsPerBulk = (6+5+(m_hostNum*(15+20+(procNum*(1+1))+(winUserNum*(1+1))+(instSWNum*(1+1))+(winSrvNum*(1+1)))));
	    lr.message("CIsPerBulk - "+ m_CIsPerBulk);
	    int nLoopCount = CIsToAdd/m_CIsPerBulk;
	    nLoopCount++; //Add another loop cause most probably the division result a remainder
	    lr.message("LoopCount - "+ nLoopCount);
            m_ipCount = (nLoopCount) * m_hostNum;
	    lr.message("m_ipCount - "+ m_ipCount);

	    return 0;
	}//end of init


	public int action() throws Throwable {
            boolean m_fddIpAsSuffix = true ;
            PopulationClient client = new PopulationClient(m_conProp,m_popProp);
	    client.init("C:\\Population.log");
	    int StartIpAsInt = ipToInt(m_sStartIP) ;
	    int EndIpAsInt = StartIpAsInt + m_ipCount;
	    lr.message("Start with - " + StartIpAsInt + " upto - " + EndIpAsInt);
	    lr.message("Start with IP - " + m_sStartIP + " upto - " + intToIp(EndIpAsInt));
	    int TotalCIsCreated = 0 ;

	    if (m_MarkStartVal!=1) {
		TotalCIsCreated+=m_CIsPerBulk ;
	    }

	    if (m_CIsToMarkForTQLs==0) {
		m_fddIpAsSuffix = false ;
		client.addIpAsSuffix(false);
		lr.message("CHNAGED SETTINGS - ADD_IP_AS_SUFFIX = false");
	    }

	    Date date;
	    String sDescription;
	    for(int ipCntr = StartIpAsInt;ipCntr<EndIpAsInt;ipCntr=ipCntr+m_hostNum){
		lr.message("IP is: "+intToIp(ipCntr));

		date = new Date();
		lr.message("Start at : " + date.toString()); 
		try{
		    sDescription = String.valueOf(m_MarkStartVal+(TotalCIsCreated/m_MarkCIsInterval))+"M";
		    lr.message("Description = " + sDescription);
		    lr.start_transaction("Population");
		    client.createSNMPTopology(ipCntr,sDescription);		
		    lr.end_transaction("Population",lr.PASS);
		}catch(Exception e){
		    lr.end_transaction("Population",lr.PASS);
		}
		date = new Date();
		lr.message("Ended at : " + date.toString());
		TotalCIsCreated+=m_CIsPerBulk ;
		lr.message("TotalCIsCreated - "+ TotalCIsCreated);
		if (m_fddIpAsSuffix==true && TotalCIsCreated>m_CIsToMarkForTQLs) {
		    m_fddIpAsSuffix = false ;
		    client.addIpAsSuffix(false);
		    lr.message("CHNAGED SETTINGS - ADD_IP_AS_SUFFIX = false");
		}
	    }
	    client.close();
	    return 0;
	}//end of action


	public int end() throws Throwable {
		return 0;
	}//end of end

        public String intToIp(int i) {
		return (i >> 24 & 0xFF) + "." + (i >> 16 & 0xFF) + "." + (i >> 8 & 0xFF) + "." + (i & 0xFF);
	}

        public int ipToInt(String sIP){
            String[] ipSections = sIP.split("\\.");
	    if(ipSections.length==4)
		return Integer.valueOf(ipSections[0])<<24 | Integer.valueOf(ipSections[1])<<16 | Integer.valueOf(ipSections[2])<<8 | Integer.valueOf(ipSections[3]);
	    return 0;
        }
	/**
         *This method is used to retrieve a string type attribute from
         *the command line parameter list. 
	 *  
	 *In case it doesn't, the Vuser exists with an lr.FAIL status.
	 *@author Eran Brand
	 *@author <a href="mailto:eran.brand@hp.com">eran.brand@hp.com</a>
	 *@param attrName The name of the attribute to be checked.
	 *@param failIfNull A flag, determines whether or not to fail
	 *                  the function in case the vaule is null
	 *@param defaultValue a default value for the param
         *@return String - the String value for the attribute or a
         *        default value in some cases.
	 *@version 1.0,  26-FEB-2009
	 *@since SDK8.01
	 */
	public String checkStringAttr(String attrName, boolean failIfNull, String defaultValue){
	if (!(attrName==null)){//we have an attribute name
		String attr = lr.get_attrib_string(attrName);
		if(attr==null){//no param value
			if(failIfNull==true){//in case a default value is no good
				lr.message(">>>"+ attrName.toString() +": No attribute value supplied. Aborting VUser.");
				lr.exit(lr.EXIT_VUSER,lr.FAIL);
				return "";
			}else{//in case we can use a default value
				if(defaultValue!=null){//there IS a default value
					return defaultValue; 
				}
				else{//no default value
					lr.message(">>>"+ attrName.toString() +": Neither param value nor default value supplied. Aborting VUser.");
					lr.exit(lr.EXIT_VUSER,lr.FAIL);
					return "";
				}
			}
		}
		else{//we have param value
			return attr;
		}
	}else{//we DONT have an attribute name at all
		lr.message(">>>"+ "No attribute name supplied. Aborting VUser.");
		lr.exit(lr.EXIT_VUSER,lr.FAIL);
		return "";
	}
	}
}
